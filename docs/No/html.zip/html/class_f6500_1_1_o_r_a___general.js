var class_f6500_1_1_o_r_a___general =
[
    [ "ORA_General", "class_f6500_1_1_o_r_a___general.html#aacdfbca486f8883b0853073c574ca6dc", null ],
    [ "executeWith", "class_f6500_1_1_o_r_a___general.html#ab4ac9e38a7848eea47cc45fe19b1abcd", null ]
];