var class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_lib_wrapper =
[
    [ "SIDLibWrapper", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_lib_wrapper.html#a843cf3c0ba72af120cfaa8aab8abc0e1", null ],
    [ "getVoiceInfoStructure", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_lib_wrapper.html#afdda93af92cd9397c2a1a86150fe356c", null ],
    [ "readValue", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_lib_wrapper.html#ad48829cf6ac1a88812201dbaac45e8e2", null ],
    [ "setValue", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_lib_wrapper.html#ade5f7b2fbbc3dbf1cbbdb594160aeadd", null ],
    [ "_lastValueRead", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_lib_wrapper.html#acc6f65a118c39375761560d12140ce0f", null ]
];