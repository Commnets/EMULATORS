var class_c_o_m_m_o_d_o_r_e_1_1_s_i_d =
[
    [ "SID", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d.html#aae728460411b89931b0d6d99abd75bae", null ],
    [ "getInfoStructure", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d.html#a767a6aab8bdf4c186ce54f953cd7a05c", null ],
    [ "initialize", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d.html#a03e52175683f9b4caa14c043e0353fe0", null ],
    [ "simulate", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d.html#ae29ea343a3fcb23617fb0c7cac08997d", null ]
];