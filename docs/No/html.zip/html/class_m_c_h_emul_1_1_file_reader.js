var class_m_c_h_emul_1_1_file_reader =
[
    [ "FileReader", "class_m_c_h_emul_1_1_file_reader.html#a97f6c9e32eeff7238ed82493900bee37", null ],
    [ "~FileReader", "class_m_c_h_emul_1_1_file_reader.html#af9f505eb06132078c9a3da4be015c652", null ],
    [ "readFile", "class_m_c_h_emul_1_1_file_reader.html#ab66c156db1474456e19958f24b7d09d0", null ]
];