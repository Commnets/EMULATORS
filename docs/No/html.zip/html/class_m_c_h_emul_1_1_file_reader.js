var class_m_c_h_emul_1_1_file_reader =
[
    [ "FileReader", "class_m_c_h_emul_1_1_file_reader.html#a97f6c9e32eeff7238ed82493900bee37", null ],
    [ "~FileReader", "class_m_c_h_emul_1_1_file_reader.html#af9f505eb06132078c9a3da4be015c652", null ],
    [ "readFile", "class_m_c_h_emul_1_1_file_reader.html#a3cab738c38444ebd41ab91935581d052", null ]
];