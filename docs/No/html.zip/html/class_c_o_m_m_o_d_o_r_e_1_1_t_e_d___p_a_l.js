var class_c_o_m_m_o_d_o_r_e_1_1_t_e_d___p_a_l =
[
    [ "TED_PAL", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d___p_a_l.html#a4b5a505bf3cd5f3472073bdc7aa11ed3", null ]
];