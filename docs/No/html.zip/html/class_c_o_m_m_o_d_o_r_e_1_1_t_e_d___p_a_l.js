var class_c_o_m_m_o_d_o_r_e_1_1_t_e_d___p_a_l =
[
    [ "TED_PAL", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d___p_a_l.html#a6a24bf662c8fdf52aaab4f6f0c662220", null ]
];