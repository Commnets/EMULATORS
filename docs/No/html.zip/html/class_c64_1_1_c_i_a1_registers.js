var class_c64_1_1_c_i_a1_registers =
[
    [ "CIA1Registers", "class_c64_1_1_c_i_a1_registers.html#a7e3a5fbc6289585a3ce870133f40a7c1", null ],
    [ "arePaddlesConnected", "class_c64_1_1_c_i_a1_registers.html#a849c956eb4e3b321fde602aba416c7ac", null ],
    [ "connectAllPaddles", "class_c64_1_1_c_i_a1_registers.html#ac982b218c6393640ab63418ce35989e6", null ],
    [ "connectPaddleAtPort", "class_c64_1_1_c_i_a1_registers.html#afa35214fcb8f88cd33c2a19167401b11", null ],
    [ "disconnectAllPaddles", "class_c64_1_1_c_i_a1_registers.html#a337dd7c379b399db4434a187a62e0c99", null ],
    [ "disconnectPaddle", "class_c64_1_1_c_i_a1_registers.html#a7d79aeca50dd80687ca4bce124a8bf43", null ],
    [ "isPaddleConnectedAtPort", "class_c64_1_1_c_i_a1_registers.html#a277d76b1252ec4aad95ad56d7a9c3323", null ],
    [ "joystickStatusAtPort", "class_c64_1_1_c_i_a1_registers.html#aa292ff0910bae8963ebf4e9bed950579", null ],
    [ "keyboardStatusMatrix", "class_c64_1_1_c_i_a1_registers.html#a2a8b54d9fd0d9a244cb62f0c914f354a", null ],
    [ "keyboardStatusMatrix", "class_c64_1_1_c_i_a1_registers.html#a4a67ff2b0e9499520dd481452534a7fb", null ],
    [ "linkToSID", "class_c64_1_1_c_i_a1_registers.html#a87acbaa33a471dd01cd9745b672a7fef", null ],
    [ "paddleFireButtonStatus", "class_c64_1_1_c_i_a1_registers.html#a94368ba463ceb60bc41b1afda5b48e87", null ],
    [ "rev_keyboardStatusMatrix", "class_c64_1_1_c_i_a1_registers.html#a45a17ea5144a763719e526a84d799b67", null ],
    [ "rev_keyboardStatusMatrix", "class_c64_1_1_c_i_a1_registers.html#ac1c658116ea11ac33fb962b85c533c6d", null ],
    [ "setJoystickStatusAtPort", "class_c64_1_1_c_i_a1_registers.html#a2ea78dc7a4bfe54f624559c591c4c77e", null ],
    [ "setKeyboardStatusMatrix", "class_c64_1_1_c_i_a1_registers.html#a2fae3808169dfdf8f7af96fc0040ca2b", null ],
    [ "setPaddleFireButtonStatus", "class_c64_1_1_c_i_a1_registers.html#a8c56da3cb55b48c72a1802918081d0d9", null ],
    [ "CIA1", "class_c64_1_1_c_i_a1_registers.html#a25a40bf970f25177c05ebc6b9dcfdcf0", null ]
];