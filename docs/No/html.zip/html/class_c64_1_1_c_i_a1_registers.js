var class_c64_1_1_c_i_a1_registers =
[
    [ "CIA1Registers", "class_c64_1_1_c_i_a1_registers.html#a0c778ae7ef041faa6790ea65149aa06d", null ],
    [ "initialize", "class_c64_1_1_c_i_a1_registers.html#ad8a34114ccd07b66414670c4a7297963", null ],
    [ "numberRegisters", "class_c64_1_1_c_i_a1_registers.html#a183f3a41468bf1bc36e5b54462ae3fc2", null ],
    [ "operator<<", "class_c64_1_1_c_i_a1_registers.html#a8a0567fd8be3af392b56be6ceab5315f", null ],
    [ "CIA1", "class_c64_1_1_c_i_a1_registers.html#a25a40bf970f25177c05ebc6b9dcfdcf0", null ]
];