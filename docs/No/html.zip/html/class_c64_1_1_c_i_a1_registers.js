var class_c64_1_1_c_i_a1_registers =
[
    [ "CIA1Registers", "class_c64_1_1_c_i_a1_registers.html#a7e3a5fbc6289585a3ce870133f40a7c1", null ],
    [ "CIA1", "class_c64_1_1_c_i_a1_registers.html#a25a40bf970f25177c05ebc6b9dcfdcf0", null ]
];