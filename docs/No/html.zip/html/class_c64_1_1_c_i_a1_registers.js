var class_c64_1_1_c_i_a1_registers =
[
    [ "CIA1Registers", "class_c64_1_1_c_i_a1_registers.html#a7e3a5fbc6289585a3ce870133f40a7c1", null ],
    [ "joystick2Status", "class_c64_1_1_c_i_a1_registers.html#a48f8b0a673789832265390b7ae3a7d11", null ],
    [ "keyboardStatusMatrix", "class_c64_1_1_c_i_a1_registers.html#a2a8b54d9fd0d9a244cb62f0c914f354a", null ],
    [ "keyboardStatusMatrix", "class_c64_1_1_c_i_a1_registers.html#a4a67ff2b0e9499520dd481452534a7fb", null ],
    [ "setJoystick2Status", "class_c64_1_1_c_i_a1_registers.html#a047ac6a88d17e4c3a50aa0b76e60d3ee", null ],
    [ "setKeyboardStatusMatrix", "class_c64_1_1_c_i_a1_registers.html#a0c70ab546998b8b593a06fe0083e27e0", null ],
    [ "setKeyboardStatusMatrix", "class_c64_1_1_c_i_a1_registers.html#a2fae3808169dfdf8f7af96fc0040ca2b", null ],
    [ "CIA1", "class_c64_1_1_c_i_a1_registers.html#a25a40bf970f25177c05ebc6b9dcfdcf0", null ]
];