var class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_sound_simple_lib_wrapper =
[
    [ "TEDSoundSimpleLibWrapper", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_sound_simple_lib_wrapper.html#afe0db5a430da48d52f0e86f37d6387d8", null ],
    [ "getData", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_sound_simple_lib_wrapper.html#a38dbc1a46f6c28b571afddd3217bba6d", null ],
    [ "getVoiceInfoStructure", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_sound_simple_lib_wrapper.html#aaced4c0dd6aec840e241b6ab493e60a0", null ],
    [ "initialize", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_sound_simple_lib_wrapper.html#a0143a0dcc2f83bfd9f1f7cf3f7f8ad24", null ],
    [ "readValue", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_sound_simple_lib_wrapper.html#a8a4e7fca2d66962331e1116f65af6517", null ],
    [ "setValue", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_sound_simple_lib_wrapper.html#ad6cbcd601bb6e68380637ef68faf076c", null ],
    [ "setVolumen", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_sound_simple_lib_wrapper.html#a8580eb1cdcb4c2630cddd6ae442325e7", null ],
    [ "volumen", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_sound_simple_lib_wrapper.html#a2132208e2c7e0eefb1faa07cf0b39999", null ]
];