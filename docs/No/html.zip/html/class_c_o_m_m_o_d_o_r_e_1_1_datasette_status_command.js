var class_c_o_m_m_o_d_o_r_e_1_1_datasette_status_command =
[
    [ "DatasetteStatusCommand", "class_c_o_m_m_o_d_o_r_e_1_1_datasette_status_command.html#af89824e665d2f996296635f8bd9b12fd", null ],
    [ "canBeExecuted", "class_c_o_m_m_o_d_o_r_e_1_1_datasette_status_command.html#a8e6077316829a42d456006bc16724ef9", null ]
];