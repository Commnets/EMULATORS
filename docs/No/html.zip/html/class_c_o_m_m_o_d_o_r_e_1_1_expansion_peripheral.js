var class_c_o_m_m_o_d_o_r_e_1_1_expansion_peripheral =
[
    [ "ExpansionPeripheral", "class_c_o_m_m_o_d_o_r_e_1_1_expansion_peripheral.html#aecd2c3b8899c7f96a17793336314d19b", null ],
    [ "_EXROM", "class_c_o_m_m_o_d_o_r_e_1_1_expansion_peripheral.html#a1c741d9ce7654895b9557fc65bda1868", null ],
    [ "_GAME", "class_c_o_m_m_o_d_o_r_e_1_1_expansion_peripheral.html#a2ab21d9458d9a124d4261de2f1aa55b1", null ],
    [ "clearData", "class_c_o_m_m_o_d_o_r_e_1_1_expansion_peripheral.html#ac7ca064a96836ce2d2e9a1fae9062390", null ],
    [ "data", "class_c_o_m_m_o_d_o_r_e_1_1_expansion_peripheral.html#afdb1b43c27ec77791131f113bebdcd25", null ],
    [ "hasDataLoaded", "class_c_o_m_m_o_d_o_r_e_1_1_expansion_peripheral.html#a32e14f991eccb7647e73313d3e4f0509", null ],
    [ "_data", "class_c_o_m_m_o_d_o_r_e_1_1_expansion_peripheral.html#acdb659911fa9fd7ceccf89fccda6290d", null ]
];