var class_m_c_h_emul_1_1_u_int_1_1_binary_format_manager =
[
    [ "add", "class_m_c_h_emul_1_1_u_int_1_1_binary_format_manager.html#a73a5408c09cd8065f93bb39cc49a8713", null ],
    [ "add", "class_m_c_h_emul_1_1_u_int_1_1_binary_format_manager.html#a73a5408c09cd8065f93bb39cc49a8713", null ],
    [ "asUnsignedInt", "class_m_c_h_emul_1_1_u_int_1_1_binary_format_manager.html#a321c845b770435b73d7c754cd3e7ea3d", null ],
    [ "asUnsignedInt", "class_m_c_h_emul_1_1_u_int_1_1_binary_format_manager.html#a321c845b770435b73d7c754cd3e7ea3d", null ],
    [ "fromInt", "class_m_c_h_emul_1_1_u_int_1_1_binary_format_manager.html#ad9f5259be322b1218505bf1dc9f7b40a", null ],
    [ "fromInt", "class_m_c_h_emul_1_1_u_int_1_1_binary_format_manager.html#ad9f5259be322b1218505bf1dc9f7b40a", null ],
    [ "fromUnsignedInt", "class_m_c_h_emul_1_1_u_int_1_1_binary_format_manager.html#a345452308360afe59d2fdcb8e602b42a", null ],
    [ "fromUnsignedInt", "class_m_c_h_emul_1_1_u_int_1_1_binary_format_manager.html#a345452308360afe59d2fdcb8e602b42a", null ],
    [ "substract", "class_m_c_h_emul_1_1_u_int_1_1_binary_format_manager.html#a576b9828795ff34cc0a24a0523f388aa", null ],
    [ "substract", "class_m_c_h_emul_1_1_u_int_1_1_binary_format_manager.html#a576b9828795ff34cc0a24a0523f388aa", null ]
];