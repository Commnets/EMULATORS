var class_m_c_h_emul_1_1_activate_deep_debug_command =
[
    [ "ActivateDeepDebugCommand", "class_m_c_h_emul_1_1_activate_deep_debug_command.html#aa413467f81a13f28b7bb3fefbaea5e41", null ],
    [ "canBeExecuted", "class_m_c_h_emul_1_1_activate_deep_debug_command.html#a925e9bdc39020ace95261ddfd1cda745", null ]
];