var class_m_c_h_emul_1_1_file_type_reader =
[
    [ "FileTypeReader", "class_m_c_h_emul_1_1_file_type_reader.html#a21a80b3dad3c2361a069b7a76b2cc2c3", null ],
    [ "~FileTypeReader", "class_m_c_h_emul_1_1_file_type_reader.html#aee831864788531cc7fa6724568f87434", null ],
    [ "FileTypeReader", "class_m_c_h_emul_1_1_file_type_reader.html#a8aa0ea7017f76dde210efedf7fbbaa41", null ],
    [ "canRead", "class_m_c_h_emul_1_1_file_type_reader.html#a63367123a0aa84cd7f7e9023e94a3bcc", null ],
    [ "operator=", "class_m_c_h_emul_1_1_file_type_reader.html#af8c082281b4dc3848e2589d1bd7a804b", null ],
    [ "operator=", "class_m_c_h_emul_1_1_file_type_reader.html#a020376b3e6fb30c55cdf955aef12e05b", null ],
    [ "readFile", "class_m_c_h_emul_1_1_file_type_reader.html#a156599701b771202bf3f2e4c6e73b3b7", null ]
];