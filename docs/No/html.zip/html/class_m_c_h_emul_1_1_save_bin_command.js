var class_m_c_h_emul_1_1_save_bin_command =
[
    [ "SaveBinCommand", "class_m_c_h_emul_1_1_save_bin_command.html#abaf7fe2d4bac5f4e893426ccdb49de65", null ],
    [ "canBeExecuted", "class_m_c_h_emul_1_1_save_bin_command.html#a6d9a1bd3b804966b095318ead6ee62d1", null ]
];