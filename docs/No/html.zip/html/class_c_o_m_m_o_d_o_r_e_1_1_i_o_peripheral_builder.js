var class_c_o_m_m_o_d_o_r_e_1_1_i_o_peripheral_builder =
[
    [ "IOPeripheralBuilder", "class_c_o_m_m_o_d_o_r_e_1_1_i_o_peripheral_builder.html#a764ae0c8aec4dadc2e83326ae9211393", null ],
    [ "createPeripheral", "class_c_o_m_m_o_d_o_r_e_1_1_i_o_peripheral_builder.html#a95c79b6eb7d4e59de829a9213bd07ba8", null ]
];