var class_c_o_m_m_o_d_o_r_e_1_1_i_o_peripheral_builder =
[
    [ "IOPeripheralBuilder", "class_c_o_m_m_o_d_o_r_e_1_1_i_o_peripheral_builder.html#a764ae0c8aec4dadc2e83326ae9211393", null ],
    [ "createPeripheral", "class_c_o_m_m_o_d_o_r_e_1_1_i_o_peripheral_builder.html#a1a62787e6f3894c42e0087dfd3326771", null ]
];