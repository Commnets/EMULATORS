var class_c264_1_1_memory =
[
    [ "Memory", "class_c264_1_1_memory.html#ae3d30436094c33000d48f5f144d4b4f3", null ],
    [ "configuration", "class_c264_1_1_memory.html#a3ad6a3361124ef8b7144fbfa33d56c6f", null ],
    [ "initialize", "class_c264_1_1_memory.html#a3a671954725957f0038dc6917bb2180d", null ],
    [ "setConfiguration", "class_c264_1_1_memory.html#a1803829f4b07d495fff8ea0742acc9d4", null ],
    [ "setConfiguration", "class_c264_1_1_memory.html#ac6f34edd12d3bdb73b1f9a483e6b9dc8", null ]
];