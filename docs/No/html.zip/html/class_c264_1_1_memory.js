var class_c264_1_1_memory =
[
    [ "Memory", "class_c264_1_1_memory.html#ae3d30436094c33000d48f5f144d4b4f3", null ],
    [ "configuration", "class_c264_1_1_memory.html#a3ad6a3361124ef8b7144fbfa33d56c6f", null ],
    [ "initialize", "class_c264_1_1_memory.html#a3a671954725957f0038dc6917bb2180d", null ],
    [ "setConfiguration", "class_c264_1_1_memory.html#a89999c66709f932fd1675130fb6200ca", null ]
];