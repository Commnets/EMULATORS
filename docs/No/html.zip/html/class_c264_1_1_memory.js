var class_c264_1_1_memory =
[
    [ "Memory", "class_c264_1_1_memory.html#ae44eeffb11addc3dd1284ec251fb919c", null ],
    [ "initialize", "class_c264_1_1_memory.html#a3a671954725957f0038dc6917bb2180d", null ],
    [ "machineType", "class_c264_1_1_memory.html#a2d9bba02232cce9abd802c97467d0e3e", null ],
    [ "setMachineType", "class_c264_1_1_memory.html#a4b37fac4c5b77b9be151cb19a35a9323", null ]
];