var class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_1_1_sound_function =
[
    [ "SoundFunction", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_1_1_sound_function.html#acc4152ac2866414c519ae52642df772c", null ],
    [ "getInfoStructure", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_1_1_sound_function.html#ab2e08c8aae4ff9ac034a6308f2fe599f", null ],
    [ "initialize", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_1_1_sound_function.html#a4bdedca425118255efb8b8448c498167", null ],
    [ "maxFrequency", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_1_1_sound_function.html#a9346fdeb7633a67928da81559dc6e5ba", null ],
    [ "numberChannels", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_1_1_sound_function.html#abc8f83fa6ee0c0104bbf013197e59dea", null ],
    [ "simulate", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_1_1_sound_function.html#a069250367ab1d9a4373a6609c6001d4d", null ],
    [ "type", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_1_1_sound_function.html#a6ca5d867f26bea3f64d944123e54a7bc", null ],
    [ "_lastCPUCycles", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_1_1_sound_function.html#a6272090344bf2eb54a3f22c63d4d4e42", null ]
];