var class_m_c_h_emul_1_1_event =
[
    [ "Data", "struct_m_c_h_emul_1_1_event_1_1_data.html", "struct_m_c_h_emul_1_1_event_1_1_data" ],
    [ "Event", "class_m_c_h_emul_1_1_event.html#a4e7839825224c34e5c613c1f599020c8", null ],
    [ "data", "class_m_c_h_emul_1_1_event.html#ac99ec9c71c5ddf70d38be034b2c98128", null ],
    [ "data", "class_m_c_h_emul_1_1_event.html#a40e7914f99d2f6576b54ab7a675712a4", null ],
    [ "id", "class_m_c_h_emul_1_1_event.html#acd9158162cf203896a82642927ead4e4", null ],
    [ "_data", "class_m_c_h_emul_1_1_event.html#ab935337a8422d3ce034f86d9813cb3ac", null ],
    [ "_id", "class_m_c_h_emul_1_1_event.html#ae7dd337242dec7a4b1ae911d1a1a87ec", null ]
];