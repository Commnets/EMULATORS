var dir_49209918626551d42fff88a62600df35 =
[
    [ "Channel.hpp", "_channel_8hpp.html", [
      [ "MCHEmul::PeerCommunicationChannel", "class_m_c_h_emul_1_1_peer_communication_channel.html", "class_m_c_h_emul_1_1_peer_communication_channel" ],
      [ "MCHEmul::PeerCommunicationChannel::MsgToSend", "struct_m_c_h_emul_1_1_peer_communication_channel_1_1_msg_to_send.html", "struct_m_c_h_emul_1_1_peer_communication_channel_1_1_msg_to_send" ]
    ] ],
    [ "incs.hpp", "_c_o_m_m_s_2incs_8hpp.html", null ],
    [ "IPAddress.hpp", "_i_p_address_8hpp.html", [
      [ "MCHEmul::IPAddress", "class_m_c_h_emul_1_1_i_p_address.html", "class_m_c_h_emul_1_1_i_p_address" ]
    ] ],
    [ "System.hpp", "_system_8hpp.html", [
      [ "MCHEmul::CommunicationSystem", "class_m_c_h_emul_1_1_communication_system.html", "class_m_c_h_emul_1_1_communication_system" ]
    ] ]
];