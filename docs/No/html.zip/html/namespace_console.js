var namespace_console =
[
    [ "Console", "class_console_1_1_console.html", "class_console_1_1_console" ]
];