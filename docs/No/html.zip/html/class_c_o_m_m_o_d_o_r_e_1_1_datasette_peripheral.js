var class_c_o_m_m_o_d_o_r_e_1_1_datasette_peripheral =
[
    [ "DatasettePeripheral", "class_c_o_m_m_o_d_o_r_e_1_1_datasette_peripheral.html#a11c04d874f95fb5e26348f1de2cc5b90", null ],
    [ "pinD4", "class_c_o_m_m_o_d_o_r_e_1_1_datasette_peripheral.html#a30345269c302151dc805defbb6c49257", null ],
    [ "pinF6", "class_c_o_m_m_o_d_o_r_e_1_1_datasette_peripheral.html#a426b972bd78ad3c6fcd3a1d38f5ca1dc", null ],
    [ "pintE5", "class_c_o_m_m_o_d_o_r_e_1_1_datasette_peripheral.html#acdf700915b3ac625db263ae34f9d1952", null ]
];