var class_c_o_m_m_o_d_o_r_e_1_1_sound_r_e_s_i_d_wrapper =
[
    [ "SoundRESIDWrapper", "class_c_o_m_m_o_d_o_r_e_1_1_sound_r_e_s_i_d_wrapper.html#a90688d511e254f2709be481792ef2e16", null ],
    [ "getData", "class_c_o_m_m_o_d_o_r_e_1_1_sound_r_e_s_i_d_wrapper.html#abad184943f6b81be104501bfc2f6406e", null ],
    [ "initialize", "class_c_o_m_m_o_d_o_r_e_1_1_sound_r_e_s_i_d_wrapper.html#ace89b4937716b42c1d0addde9bc1e2d8", null ]
];