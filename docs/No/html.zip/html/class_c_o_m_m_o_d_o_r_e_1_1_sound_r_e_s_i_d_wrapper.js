var class_c_o_m_m_o_d_o_r_e_1_1_sound_r_e_s_i_d_wrapper =
[
    [ "SoundRESIDWrapper", "class_c_o_m_m_o_d_o_r_e_1_1_sound_r_e_s_i_d_wrapper.html#a1ac61bbfe2d8e4088dca961d2e8ad0f7", null ],
    [ "getData", "class_c_o_m_m_o_d_o_r_e_1_1_sound_r_e_s_i_d_wrapper.html#a45902c71a6db45c66ec0900e9c144ad6", null ],
    [ "getVoiceInfoStructure", "class_c_o_m_m_o_d_o_r_e_1_1_sound_r_e_s_i_d_wrapper.html#ade6211adb735477794522619c54a5beb", null ],
    [ "initialize", "class_c_o_m_m_o_d_o_r_e_1_1_sound_r_e_s_i_d_wrapper.html#ace89b4937716b42c1d0addde9bc1e2d8", null ],
    [ "readValue", "class_c_o_m_m_o_d_o_r_e_1_1_sound_r_e_s_i_d_wrapper.html#aced9500eb552094631fa7c5c8152bace", null ],
    [ "setValue", "class_c_o_m_m_o_d_o_r_e_1_1_sound_r_e_s_i_d_wrapper.html#afc687ebf2c725446718ad58cf34362f5", null ]
];