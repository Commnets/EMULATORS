var class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_simple_lib_wrapper =
[
    [ "VICISoundSimpleLibWrapper", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_simple_lib_wrapper.html#a54838c71ff2409f318b8bc6b1f249804", null ],
    [ "getData", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_simple_lib_wrapper.html#a5002777e969f6463eaa6e11c2bea176e", null ],
    [ "getVoiceInfoStructure", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_simple_lib_wrapper.html#ad78524bbcac495334a18ec210a851e64", null ],
    [ "initialize", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_simple_lib_wrapper.html#a339469c7c7e42dac3049359fc034d978", null ],
    [ "readValue", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_simple_lib_wrapper.html#aed9046bc375e45022b5ef4b6ac26b1f4", null ],
    [ "setValue", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_simple_lib_wrapper.html#ad5d79b5cfe7a9be88fe00c13b1129513", null ],
    [ "setVolumen", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_simple_lib_wrapper.html#a2791c2e58fedb25a4d6673181a6fc857", null ],
    [ "volumen", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_simple_lib_wrapper.html#a94237fa9cb9cc235312ac35b75ee2e66", null ]
];