var class_m_c_h_emul_1_1_formatter =
[
    [ "Formatter", "class_m_c_h_emul_1_1_formatter.html#adc1c4c357f3a219f3be08f02c90417b7", null ],
    [ "Formatter", "class_m_c_h_emul_1_1_formatter.html#a8d0bb1fa3584a5a72362d8709d63cfb9", null ],
    [ "~Formatter", "class_m_c_h_emul_1_1_formatter.html#a2fc8d39d368c0e373039942ea2448d60", null ],
    [ "format", "class_m_c_h_emul_1_1_formatter.html#a497629cdb41dde7053c3c74340693be7", null ],
    [ "initialize", "class_m_c_h_emul_1_1_formatter.html#a609417d4d32ea287fb33a5c75629aa32", null ],
    [ "operator=", "class_m_c_h_emul_1_1_formatter.html#a44a44560e4ef2a99445b64a7d2257262", null ],
    [ "_lines", "class_m_c_h_emul_1_1_formatter.html#a0e40026bad99ea977bb371e95229f915", null ]
];