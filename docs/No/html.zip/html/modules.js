var modules =
[
    [ "Classes representing any CPU", "group___c_p_u.html", "group___c_p_u" ],
    [ "Classes representing a Parseer/Compiler emulator", "group___a_s_s_e_m_b_l_e_r.html", null ],
    [ "Classes representing the communications between server and client.", "group___c_o_m_m_s.html", null ],
    [ "Classes needed to excute an emultor from a console.", "group___c_o_n_s_o_l_e.html", null ],
    [ "Classes defining the 6500 chip family", "group___f6500.html", null ],
    [ "All classes defining the C64 Computer", "group___c64.html", null ],
    [ "All classes defining a template for any emulator.", "group___e_m_u_l_s.html", null ]
];