var class_c_o_m_m_o_d_o_r_e_1_1_sound_s_i_d_simple_wrapper =
[
    [ "SoundSIDSimpleWrapper", "class_c_o_m_m_o_d_o_r_e_1_1_sound_s_i_d_simple_wrapper.html#af6083790ce3b4a8a340407ed18e5c328", null ],
    [ "getData", "class_c_o_m_m_o_d_o_r_e_1_1_sound_s_i_d_simple_wrapper.html#a68635bd45ef879c0e5ce489a699529c9", null ],
    [ "getVoiceInfoStructure", "class_c_o_m_m_o_d_o_r_e_1_1_sound_s_i_d_simple_wrapper.html#a51ff4d24daf8fdc4d661eabcd2dbc81d", null ],
    [ "initialize", "class_c_o_m_m_o_d_o_r_e_1_1_sound_s_i_d_simple_wrapper.html#a5166c99fdf12fc20680baa9d63acb4cf", null ],
    [ "readValue", "class_c_o_m_m_o_d_o_r_e_1_1_sound_s_i_d_simple_wrapper.html#affa5cba2270043829a85c536ed5b16fd", null ],
    [ "setValue", "class_c_o_m_m_o_d_o_r_e_1_1_sound_s_i_d_simple_wrapper.html#a39517c342b5c6a0167ee52bacad9d938", null ],
    [ "setVolumen", "class_c_o_m_m_o_d_o_r_e_1_1_sound_s_i_d_simple_wrapper.html#ac50a9f388266bd596bcf3f4b51250eba", null ],
    [ "volumen", "class_c_o_m_m_o_d_o_r_e_1_1_sound_s_i_d_simple_wrapper.html#a6ad9f685cdda4c7e86d385e714c6a498", null ]
];