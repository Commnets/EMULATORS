var class_m_c_h_emul_1_1_c_p_u_speed_command =
[
    [ "CPUSpeedCommand", "class_m_c_h_emul_1_1_c_p_u_speed_command.html#a70ea75aa2a85807514de1b81bd01e4c3", null ],
    [ "CPUSpeedCommand", "class_m_c_h_emul_1_1_c_p_u_speed_command.html#a70ea75aa2a85807514de1b81bd01e4c3", null ],
    [ "canBeExecuted", "class_m_c_h_emul_1_1_c_p_u_speed_command.html#a288948f1c904a97a178deb008e3312e4", null ],
    [ "canBeExecuted", "class_m_c_h_emul_1_1_c_p_u_speed_command.html#a288948f1c904a97a178deb008e3312e4", null ]
];