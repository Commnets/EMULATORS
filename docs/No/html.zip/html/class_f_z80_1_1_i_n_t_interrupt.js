var class_f_z80_1_1_i_n_t_interrupt =
[
    [ "INTInterrupt", "class_f_z80_1_1_i_n_t_interrupt.html#aeee6008412943d904eb2f5ed72146fab", null ],
    [ "getInfoStructure", "class_f_z80_1_1_i_n_t_interrupt.html#a37f3cff2ee86a9a6ca3d3b2c39e9eb40", null ]
];