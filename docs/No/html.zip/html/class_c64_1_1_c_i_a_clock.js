var class_c64_1_1_c_i_a_clock =
[
    [ "CIAClock", "class_c64_1_1_c_i_a_clock.html#a4c5d6a15dbd3040cd7c6ff2c15fa914e", null ],
    [ "getInfoStructure", "class_c64_1_1_c_i_a_clock.html#ab4082fb6d93cf604880369a5db5b46d9", null ],
    [ "hours", "class_c64_1_1_c_i_a_clock.html#a1e19d376cc7158cf73c01e24e522af91", null ],
    [ "id", "class_c64_1_1_c_i_a_clock.html#af1e8827aad025330bc957fe75e69e125", null ],
    [ "initialize", "class_c64_1_1_c_i_a_clock.html#a2227535fd8818c98eaef2b94c82bf53f", null ],
    [ "InterruptEnabled", "class_c64_1_1_c_i_a_clock.html#a90819b41a2fdf5ec22130fd2cfcf2afa", null ],
    [ "InterruptRequested", "class_c64_1_1_c_i_a_clock.html#a83abd19f74ae96c3346eacf7ba37ba11", null ],
    [ "minutes", "class_c64_1_1_c_i_a_clock.html#af15da6d3413508705200af44ff3e8929", null ],
    [ "reachesAlarm", "class_c64_1_1_c_i_a_clock.html#af9369a3053984fa5aaaac70174ae355d", null ],
    [ "seconds", "class_c64_1_1_c_i_a_clock.html#a6606567fdeb52fb5b1f9394dba5971b8", null ],
    [ "setAlarmHours", "class_c64_1_1_c_i_a_clock.html#a0be384140816624119a5d35121df6e73", null ],
    [ "setAlarmMinutes", "class_c64_1_1_c_i_a_clock.html#a2ff389764ca2d55c557f178a3dafba21", null ],
    [ "setAlarmSeconds", "class_c64_1_1_c_i_a_clock.html#abfe5cc31462a8d61c8bf772fcf200f75", null ],
    [ "setAlarmTenthSeconds", "class_c64_1_1_c_i_a_clock.html#a998126001f6eeafe99803a40795fdd44", null ],
    [ "setHours", "class_c64_1_1_c_i_a_clock.html#a4babdd721d73cf07fab2dcd70b473c17", null ],
    [ "setInterruptEnabled", "class_c64_1_1_c_i_a_clock.html#a61784b304c0a8a4cd7824b9b448529c8", null ],
    [ "setMinutes", "class_c64_1_1_c_i_a_clock.html#a3e7cf35454cb26161f982926a5debe41", null ],
    [ "setSeconds", "class_c64_1_1_c_i_a_clock.html#aadfda60b850872a6fe10192c1eaf1d7b", null ],
    [ "setTenthSeconds", "class_c64_1_1_c_i_a_clock.html#a1e8fe5e6198e3f87b9feed70b4dbf15f", null ],
    [ "simulate", "class_c64_1_1_c_i_a_clock.html#abb6d9ad505c1f0b6bd956ee179d27f60", null ],
    [ "tenthsSecond", "class_c64_1_1_c_i_a_clock.html#ab88db16c522cc808416a80d8b765a425", null ]
];