var class_c64_1_1_c_i_a_clock =
[
    [ "CIAClock", "class_c64_1_1_c_i_a_clock.html#a90a830650939b544d5478279a8c60079", null ],
    [ "getInfoStructure", "class_c64_1_1_c_i_a_clock.html#ab4082fb6d93cf604880369a5db5b46d9", null ],
    [ "hours", "class_c64_1_1_c_i_a_clock.html#a1e19d376cc7158cf73c01e24e522af91", null ],
    [ "id", "class_c64_1_1_c_i_a_clock.html#af1e8827aad025330bc957fe75e69e125", null ],
    [ "initialize", "class_c64_1_1_c_i_a_clock.html#a2227535fd8818c98eaef2b94c82bf53f", null ],
    [ "IRQEnabled", "class_c64_1_1_c_i_a_clock.html#a52939a4c80b64950105800cc0d6d15b6", null ],
    [ "IRQRequested", "class_c64_1_1_c_i_a_clock.html#a7bcddaa73ccab3879e211c798d3c6032", null ],
    [ "minutes", "class_c64_1_1_c_i_a_clock.html#af15da6d3413508705200af44ff3e8929", null ],
    [ "reachesAlarm", "class_c64_1_1_c_i_a_clock.html#af9369a3053984fa5aaaac70174ae355d", null ],
    [ "seconds", "class_c64_1_1_c_i_a_clock.html#a6606567fdeb52fb5b1f9394dba5971b8", null ],
    [ "setAlarmHours", "class_c64_1_1_c_i_a_clock.html#a0be384140816624119a5d35121df6e73", null ],
    [ "setAlarmMinutes", "class_c64_1_1_c_i_a_clock.html#a2ff389764ca2d55c557f178a3dafba21", null ],
    [ "setAlarmSeconds", "class_c64_1_1_c_i_a_clock.html#abfe5cc31462a8d61c8bf772fcf200f75", null ],
    [ "setAlarmTenthSeconds", "class_c64_1_1_c_i_a_clock.html#a998126001f6eeafe99803a40795fdd44", null ],
    [ "setHours", "class_c64_1_1_c_i_a_clock.html#a4babdd721d73cf07fab2dcd70b473c17", null ],
    [ "setIRQEnabled", "class_c64_1_1_c_i_a_clock.html#a67ae0918e8d4fb09fb760dbca73b4115", null ],
    [ "setMinutes", "class_c64_1_1_c_i_a_clock.html#a3e7cf35454cb26161f982926a5debe41", null ],
    [ "setSeconds", "class_c64_1_1_c_i_a_clock.html#aadfda60b850872a6fe10192c1eaf1d7b", null ],
    [ "setTenthSeconds", "class_c64_1_1_c_i_a_clock.html#a1e8fe5e6198e3f87b9feed70b4dbf15f", null ],
    [ "simulate", "class_c64_1_1_c_i_a_clock.html#abb6d9ad505c1f0b6bd956ee179d27f60", null ],
    [ "tenthsSecond", "class_c64_1_1_c_i_a_clock.html#ab88db16c522cc808416a80d8b765a425", null ]
];