var class_c64_1_1_i_o6510_registers =
[
    [ "IO6510Registers", "class_c64_1_1_i_o6510_registers.html#aef1408b3fc421502e29f84a210869604", null ],
    [ "initialize", "class_c64_1_1_i_o6510_registers.html#a7f5820e28e84baf06e2c265003d0c2c3", null ],
    [ "numberRegisters", "class_c64_1_1_i_o6510_registers.html#afa84aadcae093bbe07151ace7589acfe", null ]
];