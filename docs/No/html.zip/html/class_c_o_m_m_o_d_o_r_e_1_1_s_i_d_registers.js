var class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_registers =
[
    [ "SIDRegisters", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_registers.html#acb8e0510996c1c2ab2f4b7af8decd1e2", null ],
    [ "initialize", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_registers.html#a6d68208812da109214594758f7c93ef1", null ],
    [ "numberRegisters", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_registers.html#afeabaab9f92f4747a9f529d0e7fce158", null ],
    [ "SID", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_registers.html#a9049bdd78741baef061b13821a06fce4", null ]
];