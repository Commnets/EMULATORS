var class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_registers =
[
    [ "SIDRegisters", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_registers.html#acb8e0510996c1c2ab2f4b7af8decd1e2", null ],
    [ "~SIDRegisters", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_registers.html#a9ab0df8a5697f74a224ccaaaba5e5b92", null ],
    [ "initialize", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_registers.html#a6d68208812da109214594758f7c93ef1", null ],
    [ "numberRegisters", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_registers.html#afeabaab9f92f4747a9f529d0e7fce158", null ],
    [ "potenciometerGroupActive", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_registers.html#a14196d6c3b1d403f7fde286b2f29ec72", null ],
    [ "potenciometerValue", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_registers.html#a1d2c532f7d6dcc6abbebf03302fdfe0f", null ],
    [ "setPotenciometerGroupActive", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_registers.html#abb233188f1e4653dc7194a88ef9fcbe6", null ],
    [ "setPotenciometerValue", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_registers.html#a86e874ac536f21ff2b001716aa658eb6", null ],
    [ "SID", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_registers.html#a9049bdd78741baef061b13821a06fce4", null ]
];