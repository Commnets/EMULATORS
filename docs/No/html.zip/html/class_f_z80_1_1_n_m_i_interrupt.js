var class_f_z80_1_1_n_m_i_interrupt =
[
    [ "NMIInterrupt", "class_f_z80_1_1_n_m_i_interrupt.html#a41d30d919349bc97d23d676e5b2b8bd2", null ],
    [ "getInfoStructure", "class_f_z80_1_1_n_m_i_interrupt.html#a9947f01d158f3d37c839a42a61d8dd78", null ]
];