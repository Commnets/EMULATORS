var class_c_o_m_m_o_d_o_r_e_1_1_sound_simple_wrapper =
[
    [ "SoundSimpleWrapper", "class_c_o_m_m_o_d_o_r_e_1_1_sound_simple_wrapper.html#a79d83ca4d4321c01221c522d57950de0", null ],
    [ "getData", "class_c_o_m_m_o_d_o_r_e_1_1_sound_simple_wrapper.html#a2074b86aec5b90b0c4ab824f833f4160", null ],
    [ "getVoiceInfoStructure", "class_c_o_m_m_o_d_o_r_e_1_1_sound_simple_wrapper.html#a02bcc73e27ae97c03dc65bfb0b652be5", null ],
    [ "initialize", "class_c_o_m_m_o_d_o_r_e_1_1_sound_simple_wrapper.html#ac00b579fb76db72fd2c703346bb18642", null ],
    [ "readValue", "class_c_o_m_m_o_d_o_r_e_1_1_sound_simple_wrapper.html#a18fa3bdfc8438a9d6a4f3eec1616d6e5", null ],
    [ "setValue", "class_c_o_m_m_o_d_o_r_e_1_1_sound_simple_wrapper.html#a759c546c6a11941c5cbf805b47fa0e15", null ],
    [ "setVolumen", "class_c_o_m_m_o_d_o_r_e_1_1_sound_simple_wrapper.html#aa6927c5e5053138d7b486ad912a64b03", null ],
    [ "volumen", "class_c_o_m_m_o_d_o_r_e_1_1_sound_simple_wrapper.html#aaa8cf2def646a34483725897a3648837", null ]
];