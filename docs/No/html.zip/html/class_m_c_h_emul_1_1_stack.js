var class_m_c_h_emul_1_1_stack =
[
    [ "Stack", "class_m_c_h_emul_1_1_stack.html#a49a63837426b3469558a686f5077edb1", null ],
    [ "getInfoStructure", "class_m_c_h_emul_1_1_stack.html#af4f9930f934ca8df5872a61e7c54f25d", null ],
    [ "initialize", "class_m_c_h_emul_1_1_stack.html#a3882689236dd55e78db105f6d3469dae", null ],
    [ "position", "class_m_c_h_emul_1_1_stack.html#a2ca4ec0d2724c5c7ce8fc5015d646902", null ],
    [ "pull", "class_m_c_h_emul_1_1_stack.html#aaff33fc74ed690e2296449b3e51e4c8c", null ],
    [ "push", "class_m_c_h_emul_1_1_stack.html#a4a48072ed39c54c20093414ec53564a4", null ],
    [ "setPosition", "class_m_c_h_emul_1_1_stack.html#a7962e455457aa2ec590f1fb791374bc4", null ],
    [ "stackOverflow", "class_m_c_h_emul_1_1_stack.html#a07a2ecc98f202c119af29675eee23f27", null ]
];