var class_c64_1_1_special_functions_chip_registers =
[
    [ "SpecialFunctionsChipRegisters", "class_c64_1_1_special_functions_chip_registers.html#a3fe9bce2815e2487a3eec0380114aa4c", null ],
    [ "initialize", "class_c64_1_1_special_functions_chip_registers.html#a78a568f98b2cdbb325a332409a3afd9d", null ],
    [ "numberRegisters", "class_c64_1_1_special_functions_chip_registers.html#a10c87c5cdcae1eb649943ca09981ce83", null ],
    [ "SpecialFunctionsChip", "class_c64_1_1_special_functions_chip_registers.html#a2fa1a24ec1b358480415bd50677dbf0f", null ]
];