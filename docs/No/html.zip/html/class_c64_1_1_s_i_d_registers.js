var class_c64_1_1_s_i_d_registers =
[
    [ "SIDRegisters", "class_c64_1_1_s_i_d_registers.html#afffdf1bf16563116d6ad63f6759dae17", null ],
    [ "initialize", "class_c64_1_1_s_i_d_registers.html#a3958f59b73cce3efa5f4469862e6b488", null ],
    [ "numberRegisters", "class_c64_1_1_s_i_d_registers.html#aeb459bce2d6143f44c9df16dcdccc1b3", null ],
    [ "SID", "class_c64_1_1_s_i_d_registers.html#ac8414dec3227058780b990b7778426ac", null ]
];