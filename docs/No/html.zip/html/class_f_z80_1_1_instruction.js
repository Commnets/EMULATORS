var class_f_z80_1_1_instruction =
[
    [ "Instruction", "class_f_z80_1_1_instruction.html#ad89ab464352041cf214d2d1ebc30828f", null ],
    [ "address_absolute", "class_f_z80_1_1_instruction.html#a61d7cbf1bc361a16d305000529d2fcd1", null ],
    [ "address_indexedX", "class_f_z80_1_1_instruction.html#a24c75658d9a715d7c4c1d45f259dfeb8", null ],
    [ "address_indexedY", "class_f_z80_1_1_instruction.html#ad1c96febaea1483f032bba1594a07347", null ],
    [ "value_absolute", "class_f_z80_1_1_instruction.html#a492a0faa67201ca71fd4844a671e197a", null ],
    [ "value_indexedX", "class_f_z80_1_1_instruction.html#a86554d36a2fb1e9ce8fcb27e721680d2", null ],
    [ "value_indexedY", "class_f_z80_1_1_instruction.html#a9de19c089cac8f06ad9b446b9752bfb1", null ],
    [ "value_inmediate", "class_f_z80_1_1_instruction.html#ad7130b6ca611352c3eedd26056c8b4bd", null ],
    [ "value_registerA", "class_f_z80_1_1_instruction.html#a9b8ba2de70ae516d49fd7b9f2d6e68e9", null ],
    [ "value_registerB", "class_f_z80_1_1_instruction.html#ac5033845006f29a3bdf3e11db1173b1a", null ],
    [ "value_registerC", "class_f_z80_1_1_instruction.html#a7bbc48c1509db3b2f47d16245fb9a29d", null ],
    [ "value_registerD", "class_f_z80_1_1_instruction.html#a7156f0095ae0454d79bc5c44f8250d49", null ],
    [ "value_registerE", "class_f_z80_1_1_instruction.html#a0d8fba6fa6911552e397c263f46c5ef4", null ],
    [ "value_registerH", "class_f_z80_1_1_instruction.html#a320c75a115ac4d3de79de11bd6d10aef", null ],
    [ "value_registerL", "class_f_z80_1_1_instruction.html#ad48aff0c4582ef1145fe5fe38237b515", null ]
];