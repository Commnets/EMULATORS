var class_m_c_h_emul_1_1_computer_1_1_next_command_action =
[
    [ "NextCommandAction", "class_m_c_h_emul_1_1_computer_1_1_next_command_action.html#aac945c713ee8d8a5cd044fa88af473a4", null ],
    [ "execute", "class_m_c_h_emul_1_1_computer_1_1_next_command_action.html#a5bdcfcceeb1210f725f173ff92724f52", null ]
];