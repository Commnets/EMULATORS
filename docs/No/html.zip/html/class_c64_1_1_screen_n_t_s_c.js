var class_c64_1_1_screen_n_t_s_c =
[
    [ "ScreenNTSC", "class_c64_1_1_screen_n_t_s_c.html#a2bb7a8773325f8e01975b73860e3e7f6", null ],
    [ "ScreenNTSC", "class_c64_1_1_screen_n_t_s_c.html#a2bb7a8773325f8e01975b73860e3e7f6", null ]
];