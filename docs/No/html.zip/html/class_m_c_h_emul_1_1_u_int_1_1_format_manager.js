var class_m_c_h_emul_1_1_u_int_1_1_format_manager =
[
    [ "FormatManager", "class_m_c_h_emul_1_1_u_int_1_1_format_manager.html#aa185fe4f0de4b6255a1bf0a9745892b7", null ],
    [ "add", "class_m_c_h_emul_1_1_u_int_1_1_format_manager.html#a4c4b8ab3da3ed8c255b0c4f756e6dc29", null ],
    [ "asUnsignedInt", "class_m_c_h_emul_1_1_u_int_1_1_format_manager.html#a68026e326d65b68b83479c99bb237be3", null ],
    [ "fromInt", "class_m_c_h_emul_1_1_u_int_1_1_format_manager.html#a09e38750c3486f3f580578e57dcfa7ce", null ],
    [ "fromUnsignedInt", "class_m_c_h_emul_1_1_u_int_1_1_format_manager.html#ae57ced43caa73a99f8532ee5422a47d6", null ],
    [ "substract", "class_m_c_h_emul_1_1_u_int_1_1_format_manager.html#abe6b82300136824c32473d651d2ec256", null ]
];