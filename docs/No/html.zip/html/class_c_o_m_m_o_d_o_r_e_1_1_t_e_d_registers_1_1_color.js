var class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_registers_1_1_color =
[
    [ "Color", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_registers_1_1_color.html#ad36ce11fca9c55885c0b17e02e262e49", null ],
    [ "Color", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_registers_1_1_color.html#a5e69a51069d35d6f42853a7fac8adf50", null ],
    [ "asChar", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_registers_1_1_color.html#a4fda38da731afeb72952b98300c4e4f9", null ],
    [ "getInfoStructure", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_registers_1_1_color.html#a43765b6c92e8f34f5ad36b49dc9d8a93", null ],
    [ "nextLuminance", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_registers_1_1_color.html#ad6531dcdda4ed1221f18d5c5a1db700c", null ],
    [ "_color", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_registers_1_1_color.html#ad337fedc0a9b19a02cbe7aa7da1a2395", null ],
    [ "_luminance", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_registers_1_1_color.html#a8b478661542110377c3d7e39dbb562c8", null ]
];