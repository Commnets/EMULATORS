var class_f_z80_1_1_c_a_l_l___general =
[
    [ "CALL_General", "class_f_z80_1_1_c_a_l_l___general.html#a1d7573d7b1f3624f24c6c67c37a81f44", null ],
    [ "executeBranch", "class_f_z80_1_1_c_a_l_l___general.html#afbcde012a68076a455f8f5f454a4d111", null ]
];