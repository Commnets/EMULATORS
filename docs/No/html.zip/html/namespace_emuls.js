var namespace_emuls =
[
    [ "C64Emulator", "class_emuls_1_1_c64_emulator.html", "class_emuls_1_1_c64_emulator" ],
    [ "Emulator", "class_emuls_1_1_emulator.html", "class_emuls_1_1_emulator" ]
];