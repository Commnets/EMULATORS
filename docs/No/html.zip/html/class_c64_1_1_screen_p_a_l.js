var class_c64_1_1_screen_p_a_l =
[
    [ "ScreenPAL", "class_c64_1_1_screen_p_a_l.html#a2013706b6e4483e6c34cf510cdbf50d9", null ]
];