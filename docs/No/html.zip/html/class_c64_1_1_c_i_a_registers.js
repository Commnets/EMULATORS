var class_c64_1_1_c_i_a_registers =
[
    [ "CIARegisters", "class_c64_1_1_c_i_a_registers.html#a1d0706b2c2c45de171f30ac644f9947e", null ],
    [ "initialize", "class_c64_1_1_c_i_a_registers.html#abff495db18fdf4bdb123ecba45d55248", null ],
    [ "initializeInternalValues", "class_c64_1_1_c_i_a_registers.html#afbc664290c8c01400b7b95ea15d3f013", null ],
    [ "lookAtClock", "class_c64_1_1_c_i_a_registers.html#afc6461b6ea3f95796fcb16fd63062ff0", null ],
    [ "lookAtTimers", "class_c64_1_1_c_i_a_registers.html#a7e46d7ff51509874229c63973b4b49a1", null ],
    [ "numberRegisters", "class_c64_1_1_c_i_a_registers.html#a7c48c5add43a6c30f9d672455716369c", null ],
    [ "readValue", "class_c64_1_1_c_i_a_registers.html#a2e0b80138436f4ba87b57e09d12d32a8", null ],
    [ "setValue", "class_c64_1_1_c_i_a_registers.html#a5c4c6d740b64c23bfde2904205f378b9", null ],
    [ "_clock", "class_c64_1_1_c_i_a_registers.html#a74db4a3108b9122e36d2ac47a7a2d96c", null ],
    [ "_lastValueRead", "class_c64_1_1_c_i_a_registers.html#a555b79cf876bda3dbff958a1ced5b0ae", null ],
    [ "_timerA", "class_c64_1_1_c_i_a_registers.html#a8394bf4e69872ee1102cf64a88ded3e6", null ],
    [ "_timerB", "class_c64_1_1_c_i_a_registers.html#a6ae1e28f88f15d1136b887cb16324d30", null ],
    [ "CIA", "class_c64_1_1_c_i_a_registers.html#a08fad0deef181788e0fb953fefc97865", null ]
];