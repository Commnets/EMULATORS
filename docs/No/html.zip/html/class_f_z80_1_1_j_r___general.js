var class_f_z80_1_1_j_r___general =
[
    [ "JR_General", "class_f_z80_1_1_j_r___general.html#add74511c11a2a9e8183c99304084a039", null ],
    [ "executeBranch", "class_f_z80_1_1_j_r___general.html#aabb1559223eeed536ef6598a19948ff7", null ]
];