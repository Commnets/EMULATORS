var class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port =
[
    [ "Status", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#a4df10247412897dde66338474c438518", [
      [ "_READING", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#a4df10247412897dde66338474c438518ad0a4c930571f6e205347012099434043", null ],
      [ "_SAVING", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#a4df10247412897dde66338474c438518aead0f2131a9e72d5d3070eaf6d8d16e0", null ]
    ] ],
    [ "CIASerialPort", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#ad8b0dce39630c71350ba2726dbb0a60c", null ],
    [ "CNTSignal", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#a3061e6081b96ca31c752e642c756f45c", null ],
    [ "getInfoStructure", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#a3586eaa6fdd487ed09366852918b46ce", null ],
    [ "initialize", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#acdc09b723a0576e9af8305fe321fee14", null ],
    [ "interruptEnabled", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#afde54aa7e5e711da484330df12c046a2", null ],
    [ "interruptRequested", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#aad775c6f26515ae1119fd004bbcaf4d2", null ],
    [ "launchInterruption", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#a1335a950eaa2a96e515f3cfe409c854c", null ],
    [ "peekInterruptRequested", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#a5968c1b8e6561ef9b78fb1be27fc4f87", null ],
    [ "setCNTSignal", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#abd489eab141a2c47fe36b311d154c528", null ],
    [ "setInterruptEnabled", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#ac3722ac9ed3d83654ad8795b668ed898", null ],
    [ "setSPSignal", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#a71745050f3556dc1134fc7a703609e4e", null ],
    [ "setStatus", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#aa11314f51ad124ee6d057138803471f5", null ],
    [ "setValue", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#a27004547b58b69cc645fc531854c2db5", null ],
    [ "simulate", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#aca31e698c47238152f245ae00533f7b6", null ],
    [ "SPSignal", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#a5cb8473d6a8c700e0e0dd9a5b6e8062a", null ],
    [ "status", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#ad7c4cd38ebab28e1f3439b2a8ff32e34", null ],
    [ "value", "class_c_o_m_m_o_d_o_r_e_1_1_c_i_a_serial_port.html#ada312be8285b27d39666c15b8ff5a4ca", null ]
];