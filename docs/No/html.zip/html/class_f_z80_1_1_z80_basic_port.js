var class_f_z80_1_1_z80_basic_port =
[
    [ "Z80BasicPort", "class_f_z80_1_1_z80_basic_port.html#a3c51276981969726c0ca2178db99b1b3", null ],
    [ "setValue", "class_f_z80_1_1_z80_basic_port.html#afcecc69b696a0814c965b99e86a68db8", null ],
    [ "value", "class_f_z80_1_1_z80_basic_port.html#a94e79471a0bf1996583a91b06acaf0fb", null ]
];