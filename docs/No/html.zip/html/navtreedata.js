/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "EMULATORS", "index.html", [
    [ "Modules", "modules.html", "modules" ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Typedefs", "namespacemembers_type.html", null ],
        [ "Enumerations", "namespacemembers_enum.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", "functions_vars" ],
        [ "Typedefs", "functions_type.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Enumerator", "functions_eval.html", null ],
        [ "Related Functions", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_a_s_s_e_m_b_l_e_r_2incs_8hpp.html",
"_instructions_8hpp.html#aa9b4e140ea6c21796038e951efb0d111",
"class_c64_1_1_i_o_peripheral_builder.html",
"class_c64_1_1_v_i_c_i_i_registers.html#a29d9d3dacec08ac8c9ec64d245ef6776",
"class_f6500_1_1_c6500.html#a5654c4caf5994e89d31bf84e6ae2fde8a78a8a1eab3b9ab4d83a29ab249774dcd",
"class_m_c_h_emul_1_1_address.html#ad430a2b6338964f32de2067547d4d39e",
"class_m_c_h_emul_1_1_c_p_u.html#a84fb2e92ed3d4ffbbaf811f151304275",
"class_m_c_h_emul_1_1_computer.html#a2ea5a5adac5539a496f82e1bb2310dca",
"class_m_c_h_emul_1_1_i_o_peripheral_builder.html#aee0cf286f68b9939795a7b19e3e720a4",
"class_m_c_h_emul_1_1_memory_1_1_content.html#ad14149e8e2342e6dbf02006374380969",
"class_m_c_h_emul_1_1_phisical_storage_subset.html#af20632928476477041fa71cd4a0d64d1",
"class_m_c_h_emul_1_1_u_byte.html#a0926228fa4243b2ec132ade2a122c9ab",
"class_m_c_h_emul_1_1_u_int_1_1_binary_format_manager.html#a576b9828795ff34cc0a24a0523f388aa",
"namespace_f6500.html#ac2bb00a29369d0b182119f4224809a14",
"struct_m_c_h_emul_1_1_instruction_1_1_structure.html#a1050e3c052f26b6ace1fc6b8b160fd73"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';