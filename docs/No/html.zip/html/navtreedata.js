/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "EMULATORS", "index.html", [
    [ "Modules", "modules.html", "modules" ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Typedefs", "namespacemembers_type.html", null ],
        [ "Enumerations", "namespacemembers_enum.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", "functions_vars" ],
        [ "Typedefs", "functions_type.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Enumerator", "functions_eval.html", null ],
        [ "Related Functions", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_a_s_s_e_m_b_l_e_r_2incs_8hpp.html",
"_instructions_8hpp.html#aa390431a948096520037a3cf22c25bc7",
"class_c64_1_1_commodore64.html#ae302960f959db9023db88c48385096d8",
"class_c64_1_1_v_i_c_i_i_registers.html#a24f14eef92d37dadf910b47b46a6eb8b",
"class_f6500_1_1_c6500.html#a5654c4caf5994e89d31bf84e6ae2fde8",
"class_m_c_h_emul_1_1_address.html#a9a59acf5825bc470dbe6681cf1f536a4",
"class_m_c_h_emul_1_1_c_p_u.html#a63bc102fb07363d27c6a5039d1914f36",
"class_m_c_h_emul_1_1_communication_system.html#a59a595dd8e360055f60b71aff767f029",
"class_m_c_h_emul_1_1_i_o_peripheral.html#a00122c4a64a7a678f3a85db3b6c4ea3d",
"class_m_c_h_emul_1_1_memory.html#adbd620564981bb4dbd40eb1c9511c81e",
"class_m_c_h_emul_1_1_phisical_storage_subset.html#a2a8633458c194b9017e4725ebde3b098",
"class_m_c_h_emul_1_1_stack.html",
"class_m_c_h_emul_1_1_u_int.html#a2727063245b6eea9675d4f918b962b8b",
"namespace_f6500.html#a3fc50a8707bc99ea4f6e6d4dc2b36efd",
"struct_m_c_h_emul_1_1_assembler_1_1_grammatical_element.html#a62e3400a7525415a19a53e6d250ea320"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';