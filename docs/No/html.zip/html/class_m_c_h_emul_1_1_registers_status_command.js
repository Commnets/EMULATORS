var class_m_c_h_emul_1_1_registers_status_command =
[
    [ "RegistersStatusCommand", "class_m_c_h_emul_1_1_registers_status_command.html#ad709a50f591462992c24c281ad5bc7f7", null ],
    [ "canBeExecuted", "class_m_c_h_emul_1_1_registers_status_command.html#a0319d21d3fbe92ab878a08861a75629b", null ]
];