var class_m_c_h_emul_1_1_computer_1_1_stop_action =
[
    [ "StopAction", "class_m_c_h_emul_1_1_computer_1_1_stop_action.html#a4d70b59a6191de47665af625f3834cfd", null ],
    [ "execute", "class_m_c_h_emul_1_1_computer_1_1_stop_action.html#ad53b2fd065a25666a70a430793d6b539", null ]
];