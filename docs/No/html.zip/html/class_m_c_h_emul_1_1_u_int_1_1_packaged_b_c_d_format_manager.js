var class_m_c_h_emul_1_1_u_int_1_1_packaged_b_c_d_format_manager =
[
    [ "add", "class_m_c_h_emul_1_1_u_int_1_1_packaged_b_c_d_format_manager.html#a22ee7e1b2ae46ced1944c618996348e4", null ],
    [ "asUnsignedInt", "class_m_c_h_emul_1_1_u_int_1_1_packaged_b_c_d_format_manager.html#ad3e80ed292281e6da80a8e4503f2825b", null ],
    [ "fromInt", "class_m_c_h_emul_1_1_u_int_1_1_packaged_b_c_d_format_manager.html#a91379e6bb38a8e2aebb203461060e4e6", null ],
    [ "fromUnsignedInt", "class_m_c_h_emul_1_1_u_int_1_1_packaged_b_c_d_format_manager.html#a966a1df5b5fa1553798b8c1329359e32", null ],
    [ "substract", "class_m_c_h_emul_1_1_u_int_1_1_packaged_b_c_d_format_manager.html#a3023bd471bfac3b4f14edeb0da41f9c9", null ]
];