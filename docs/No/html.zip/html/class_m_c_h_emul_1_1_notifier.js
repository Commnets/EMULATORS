var class_m_c_h_emul_1_1_notifier =
[
    [ "~Notifier", "class_m_c_h_emul_1_1_notifier.html#a1269d8c23c003f6a117e027391d747e0", null ],
    [ "addObserver", "class_m_c_h_emul_1_1_notifier.html#a2e5e14a2c3340859ab29f79e93b1b730", null ],
    [ "notify", "class_m_c_h_emul_1_1_notifier.html#a7a96eb7b8f72c29f7d67243c0d981b78", null ],
    [ "removeObserver", "class_m_c_h_emul_1_1_notifier.html#aba2385f4cb77519db6c2b43fece5bcb4", null ],
    [ "_observers", "class_m_c_h_emul_1_1_notifier.html#a5462edb184e79982635402cfb7d1eaed", null ],
    [ "Observer", "class_m_c_h_emul_1_1_notifier.html#a6e5af0d6c96f4b015fc50582d09c3429", null ]
];