var class_c_o_m_m_o_d_o_r_e_1_1_sound_pulse_wrapper =
[
    [ "SoundPulseWrapper", "class_c_o_m_m_o_d_o_r_e_1_1_sound_pulse_wrapper.html#a7995b87ab1ef9c75d0346bead13a5181", null ],
    [ "getData", "class_c_o_m_m_o_d_o_r_e_1_1_sound_pulse_wrapper.html#a7920b58171b2cc1e7288c6d5f1c8dec9", null ],
    [ "setParameters", "class_c_o_m_m_o_d_o_r_e_1_1_sound_pulse_wrapper.html#ade93a6879e4cbfe4340ef19eeb940fe3", null ]
];