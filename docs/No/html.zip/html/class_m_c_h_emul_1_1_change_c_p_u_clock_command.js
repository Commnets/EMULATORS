var class_m_c_h_emul_1_1_change_c_p_u_clock_command =
[
    [ "ChangeCPUClockCommand", "class_m_c_h_emul_1_1_change_c_p_u_clock_command.html#a62d2d914c35708af1d5f1d8e4aad98df", null ],
    [ "canBeExecuted", "class_m_c_h_emul_1_1_change_c_p_u_clock_command.html#aacbe916a60d161ffd6c37a5c50a4f814", null ]
];