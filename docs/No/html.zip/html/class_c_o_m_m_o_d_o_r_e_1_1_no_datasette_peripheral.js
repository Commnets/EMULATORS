var class_c_o_m_m_o_d_o_r_e_1_1_no_datasette_peripheral =
[
    [ "NoDatasettePeripheral", "class_c_o_m_m_o_d_o_r_e_1_1_no_datasette_peripheral.html#acd070453bf103900cd837a93c105e1fc", null ],
    [ "simulate", "class_c_o_m_m_o_d_o_r_e_1_1_no_datasette_peripheral.html#a0d3d383069005597c22d8513b7377f2c", null ]
];