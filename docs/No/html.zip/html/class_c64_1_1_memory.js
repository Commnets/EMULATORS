var class_c64_1_1_memory =
[
    [ "Memory", "class_c64_1_1_memory.html#ab80066cd89630bef5928a94f0447ae42", null ],
    [ "configureMemoryAccess", "class_c64_1_1_memory.html#a5e62dc9afe629a3eeadc1edbd48b9c73", null ],
    [ "initialize", "class_c64_1_1_memory.html#aa826e237001607c60d48ea3646bbb1b5", null ]
];