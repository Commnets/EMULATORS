var class_f_z80_1_1_o_r___general =
[
    [ "OR_General", "class_f_z80_1_1_o_r___general.html#a11855e695d64953abbde12c149e22768", null ],
    [ "executeWith", "class_f_z80_1_1_o_r___general.html#a9f5b09e76c4c9b42c42b93fb31626599", null ]
];