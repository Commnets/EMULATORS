var class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers =
[
    [ "GraphicMode", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a0cca357c9a93d3e6c6a42e306283f599", [
      [ "_CHARMODE", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a0cca357c9a93d3e6c6a42e306283f599aa73b0934151e7f07e112ebf71c342185", null ],
      [ "_MULTICOLORCHARMODE", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a0cca357c9a93d3e6c6a42e306283f599a3fd99cd6d0b4c61258aa21d585c775a2", null ]
    ] ],
    [ "VICIRegisters", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#acf0b58d0d2729f2d46837c2534b64027", null ],
    [ "getInfoStructure", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#ab29fee6b1d2b6af883e236c5f0fbe882", null ],
    [ "initialize", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a4ef285d83f1bf601276410e9478372a6", null ],
    [ "numberRegisters", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a963055e1d4dc67913d0088d2c95dbf30", null ]
];