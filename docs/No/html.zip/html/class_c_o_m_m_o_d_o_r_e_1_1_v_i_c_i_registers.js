var class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers =
[
    [ "GraphicMode", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a0cca357c9a93d3e6c6a42e306283f599", [
      [ "_CHARMODE", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a0cca357c9a93d3e6c6a42e306283f599aa73b0934151e7f07e112ebf71c342185", null ],
      [ "_MULTICOLORCHARMODE", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a0cca357c9a93d3e6c6a42e306283f599a3fd99cd6d0b4c61258aa21d585c775a2", null ]
    ] ],
    [ "VICIRegisters", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#acf0b58d0d2729f2d46837c2534b64027", null ],
    [ "auxiliarColor", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a9459b855b4229f7712465aba357447ef", null ],
    [ "borderColor", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#aed6031ac0fc38bf39709d9a6e3e4da12", null ],
    [ "charHeightScreen", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#aff516356b7ec5ae5a0b184bc9fe843bb", null ],
    [ "charsExpanded", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a9cb9abf2b13da7946008c8571d5de63c", null ],
    [ "charsWidthScreen", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#af500989e3db472b8591fc933022082b1", null ],
    [ "currentLightPenHorizontalPosition", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#ae65e7eccf9517869355806e9f2911212", null ],
    [ "currentLightPenPosition", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#ab27a5f5d1c860200f5ce0211a8aee064", null ],
    [ "currentLightPenVerticalPosition", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#affb4e004c47f3a1bf6871e3cdbc84d3d", null ],
    [ "currentRasterLine", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a7365501be56be68712b8f997add51ea5", null ],
    [ "getInfoStructure", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#ab29fee6b1d2b6af883e236c5f0fbe882", null ],
    [ "initialize", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a4ef285d83f1bf601276410e9478372a6", null ],
    [ "interlacedActive", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a97411477dec2fb2a515f337f38ecc142", null ],
    [ "inverseMode", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a06c37de2afdfc75688fa5172333b2676", null ],
    [ "lightPenActive", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a3d92313ebd31abeb99ce2c5f8cc20417", null ],
    [ "numberRegisters", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a963055e1d4dc67913d0088d2c95dbf30", null ],
    [ "offsetXScreen", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a46ef99e513a52b777a3f0e0838d8ff40", null ],
    [ "offsetYScreen", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a3f188e583076d8442563a08dd031b50e", null ],
    [ "screenColor", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#af645ccd66a61e4852aca9a29f86988be", null ],
    [ "setCurrentLightPenPosition", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a11fba7370edceb3e2865affdeab93229", null ],
    [ "setCurrentRasterLine", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#aff7c4e200d668ed4919d0052005466b3", null ],
    [ "setLigthPenActive", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#abe38824be7d7ffed6c354fb1bbb4c14a", null ],
    [ "setSoundLibWrapper", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_registers.html#a746783bb8292897d21ed4924fd172e19", null ]
];