var class_c_o_m_m_o_d_o_r_e_1_1_t_i_a_registers =
[
    [ "TIARegisters", "class_c_o_m_m_o_d_o_r_e_1_1_t_i_a_registers.html#accec7c08d7ef2b83947cfe5a7fa47536", null ],
    [ "getInfoStructure", "class_c_o_m_m_o_d_o_r_e_1_1_t_i_a_registers.html#a05084738f64f3a01e0061af88c4b81f9", null ],
    [ "initialize", "class_c_o_m_m_o_d_o_r_e_1_1_t_i_a_registers.html#a8d9e2fa41fea9d734bd129018359387e", null ],
    [ "numberRegisters", "class_c_o_m_m_o_d_o_r_e_1_1_t_i_a_registers.html#ab8e797ce550c20556af01a34ebb74a05", null ],
    [ "TIA", "class_c_o_m_m_o_d_o_r_e_1_1_t_i_a_registers.html#a263920e05756fc95a40afdfec72ceac1", null ]
];