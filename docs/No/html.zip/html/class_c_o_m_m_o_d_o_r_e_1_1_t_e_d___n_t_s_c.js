var class_c_o_m_m_o_d_o_r_e_1_1_t_e_d___n_t_s_c =
[
    [ "TED_NTSC", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d___n_t_s_c.html#a53a260cb86facf6aa76f27319971e6ac", null ]
];