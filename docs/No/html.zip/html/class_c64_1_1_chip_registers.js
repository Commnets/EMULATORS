var class_c64_1_1_chip_registers =
[
    [ "ChipRegisters", "class_c64_1_1_chip_registers.html#aac5e4ba7b0d4a849e0ec741e3501c0d4", null ],
    [ "getInfoStructure", "class_c64_1_1_chip_registers.html#ad09d55c112c83750a9713cc6a9b1761d", null ],
    [ "numberRegisters", "class_c64_1_1_chip_registers.html#ac88720eda0c7bcd6a17e2e3829c3a7e6", null ],
    [ "valueRegisters", "class_c64_1_1_chip_registers.html#a0e9ccb64d897015206d9c3024e5e3efe", null ]
];