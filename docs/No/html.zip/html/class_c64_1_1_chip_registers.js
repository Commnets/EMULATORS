var class_c64_1_1_chip_registers =
[
    [ "ChipRegisters", "class_c64_1_1_chip_registers.html#a1c00c6d8698490012ca6d3bad4fafe7b", null ],
    [ "numberRegisters", "class_c64_1_1_chip_registers.html#ac88720eda0c7bcd6a17e2e3829c3a7e6", null ],
    [ "operator<<", "class_c64_1_1_chip_registers.html#aeb45e8318b73ac4f6f81dc4b6b7ea2d7", null ]
];