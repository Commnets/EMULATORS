var class_c64_1_1_c_i_a2_registers =
[
    [ "CIA2Registers", "class_c64_1_1_c_i_a2_registers.html#ae8b50a471209b8423bbe5fd48d2f28ee", null ],
    [ "CIA2Registers", "class_c64_1_1_c_i_a2_registers.html#ae8b50a471209b8423bbe5fd48d2f28ee", null ],
    [ "VICIIBank", "class_c64_1_1_c_i_a2_registers.html#a147e1cb697b549882310ecd5f3e10372", null ],
    [ "VICIIBank", "class_c64_1_1_c_i_a2_registers.html#a147e1cb697b549882310ecd5f3e10372", null ],
    [ "CIA2", "class_c64_1_1_c_i_a2_registers.html#a6f40fc557f0056a23c04da7bf33f063a", null ]
];