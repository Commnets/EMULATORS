var class_f_z80_1_1_c_z80 =
[
    [ "CZ80", "class_f_z80_1_1_c_z80.html#a8924a4b0d4ae0295d917e8fcde940cd8", null ],
    [ "apRegister", "class_f_z80_1_1_c_z80.html#ac2296e2c95d758c81e821386e6461bd4", null ],
    [ "aRegister", "class_f_z80_1_1_c_z80.html#a11a819d00b63bdf6c88771b09771a70e", null ],
    [ "bpRegister", "class_f_z80_1_1_c_z80.html#a7f373944c97b7d64dc5fe22382962522", null ],
    [ "bRegister", "class_f_z80_1_1_c_z80.html#a6b2f10dc900d4fc8ecbdca402bcd6e11", null ],
    [ "cpRegister", "class_f_z80_1_1_c_z80.html#a5c3d1e5758dd06aedd65833361c29b0b", null ],
    [ "cRegister", "class_f_z80_1_1_c_z80.html#ae8a9509b0548df123ddd2124c02bf55d", null ],
    [ "dpRegister", "class_f_z80_1_1_c_z80.html#afc1faabd517229a5a3a38c6260a69e15", null ],
    [ "dRegister", "class_f_z80_1_1_c_z80.html#a82827540b8591ad81facffbd4b9e4e48", null ],
    [ "epRegister", "class_f_z80_1_1_c_z80.html#ad85fe5db34eeddb543e65a6db14d769e", null ],
    [ "eRegister", "class_f_z80_1_1_c_z80.html#ac89130c610b25287f32c489dcf640686", null ],
    [ "fpRegister", "class_f_z80_1_1_c_z80.html#a91f70f5262d76d772acc411745904475", null ],
    [ "fRegister", "class_f_z80_1_1_c_z80.html#ad9ba5877e2f8ee902843643ee77556ef", null ],
    [ "hpRegister", "class_f_z80_1_1_c_z80.html#a2742cc1bce6ffb0c6d3abc516dbee341", null ],
    [ "hRegister", "class_f_z80_1_1_c_z80.html#a9e8650f222f37796cedd0c79f67f9c1e", null ],
    [ "ixRegister", "class_f_z80_1_1_c_z80.html#a9e716cc3fac6cf45f72be1c9c7f956b0", null ],
    [ "iyRegister", "class_f_z80_1_1_c_z80.html#a5462ba35bc8eb6741148178e3b302fbc", null ],
    [ "kpRegister", "class_f_z80_1_1_c_z80.html#a2226b2022f224d2078dbf40de909ceb1", null ],
    [ "kRegister", "class_f_z80_1_1_c_z80.html#a1dfe156a7a3a52bc78f6600f5beef8ae", null ]
];