var class_c264_1_1_r_o_m_r_a_m_switch_registers =
[
    [ "ROMRAMSwitchRegisters", "class_c264_1_1_r_o_m_r_a_m_switch_registers.html#a955922938a2edac379100b85b2e4af30", null ],
    [ "allowROMConfiguration", "class_c264_1_1_r_o_m_r_a_m_switch_registers.html#a02736fd987f5b8372179d5a78610f547", null ],
    [ "configurationChanged", "class_c264_1_1_r_o_m_r_a_m_switch_registers.html#a1ec0a3c220f8bda4024e67b40f812004", null ],
    [ "configurationROM", "class_c264_1_1_r_o_m_r_a_m_switch_registers.html#a86c7cc77c65ac93845b335679c23be20", null ],
    [ "getInfoStructure", "class_c264_1_1_r_o_m_r_a_m_switch_registers.html#aed96d2308dd5c9e95cf2968f9f0ab7d0", null ],
    [ "initialize", "class_c264_1_1_r_o_m_r_a_m_switch_registers.html#aa664ca06678714de35e9dcacaf36076f", null ],
    [ "numberRegisters", "class_c264_1_1_r_o_m_r_a_m_switch_registers.html#a0472db511abc739d76734dc59849f2ee", null ],
    [ "peekConfigurationChanged", "class_c264_1_1_r_o_m_r_a_m_switch_registers.html#a986b32140ccbbc7cad015d8c5746290c", null ],
    [ "ROMRAMSwitch", "class_c264_1_1_r_o_m_r_a_m_switch_registers.html#ab3433748069514272e10a9c2c4d0d93b", null ]
];