var class_c_o_m_m_o_d_o_r_e_1_1_t_a_p_file_type_i_o =
[
    [ "TAPFileTypeIO", "class_c_o_m_m_o_d_o_r_e_1_1_t_a_p_file_type_i_o.html#a018e1f7823711b9d6428e8576a6ca1c6", null ],
    [ "canRead", "class_c_o_m_m_o_d_o_r_e_1_1_t_a_p_file_type_i_o.html#ac04c841b305c781263958225e39b5e50", null ],
    [ "canWrite", "class_c_o_m_m_o_d_o_r_e_1_1_t_a_p_file_type_i_o.html#a6a39160d6c0fe621a070c65a737d0c98", null ],
    [ "readFile", "class_c_o_m_m_o_d_o_r_e_1_1_t_a_p_file_type_i_o.html#a13ae2cba9ea9e821189c525966e5baef", null ],
    [ "writeFile", "class_c_o_m_m_o_d_o_r_e_1_1_t_a_p_file_type_i_o.html#ae527a2b49e6b287ba84873c9d2266c81", null ]
];