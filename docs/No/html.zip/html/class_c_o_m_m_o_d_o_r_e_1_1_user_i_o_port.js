var class_c_o_m_m_o_d_o_r_e_1_1_user_i_o_port =
[
    [ "UserIOPort", "class_c_o_m_m_o_d_o_r_e_1_1_user_i_o_port.html#a57710e04f6ab14ed1e092f2a3eeaa6ea", null ],
    [ "connectPeripheral", "class_c_o_m_m_o_d_o_r_e_1_1_user_i_o_port.html#ab9daa289253f817229bdd5f2b4c529db", null ]
];