var class_c264_1_1_c6529_b2_registers =
[
    [ "C6529B2Registers", "class_c264_1_1_c6529_b2_registers.html#ac54aade02f26348c883babc581587e80", null ],
    [ "numberRegisters", "class_c264_1_1_c6529_b2_registers.html#a4c4c9c538d1d2b3b6869b046d73dd31f", null ],
    [ "C6529B2", "class_c264_1_1_c6529_b2_registers.html#af5a95d7dbbb360a255d224708abfff62", null ]
];