var class_c_o_m_m_o_d_o_r_e_1_1_c6529_b_registers =
[
    [ "C6529BRegisters", "class_c_o_m_m_o_d_o_r_e_1_1_c6529_b_registers.html#ac9bf3b67edf775d88235ab3d4b6663c1", null ],
    [ "getInfoStructure", "class_c_o_m_m_o_d_o_r_e_1_1_c6529_b_registers.html#a60da9fe0d16bf670db1c80cafcc4f29e", null ],
    [ "numberRegisters", "class_c_o_m_m_o_d_o_r_e_1_1_c6529_b_registers.html#afca04a30ab7ed21e57547075485910cc", null ],
    [ "C6529B", "class_c_o_m_m_o_d_o_r_e_1_1_c6529_b_registers.html#a4e55875d866c6deae077ac8bc51f7122", null ]
];