var class_f_z80_1_1_b_i_t___index =
[
    [ "BIT_Index", "class_f_z80_1_1_b_i_t___index.html#ad065c098c75b2f00f3b08ee035b6a2f0", null ],
    [ "shapeCodeWithData", "class_f_z80_1_1_b_i_t___index.html#a2c2f12c52170a3b5853006f3a5f998d9", null ]
];