var functions_vars =
[
    [ "_", "functions_vars.html", null ],
    [ "c", "functions_vars_c.html", null ],
    [ "i", "functions_vars_i.html", null ],
    [ "m", "functions_vars_m.html", null ],
    [ "p", "functions_vars_p.html", null ]
];