var class_c_o_m_m_o_d_o_r_e_1_1_v_i_a_status_command =
[
    [ "VIAStatusCommand", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_a_status_command.html#a6d2d3d6ca37ad799a4037979909990fd", null ],
    [ "canBeExecuted", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_a_status_command.html#a54726d12dca62650dca66a2893c9b8be", null ]
];