var class_c64_1_1_v_i_c_i_i___joystick_event =
[
    [ "VICII_JoystickEvent", "class_c64_1_1_v_i_c_i_i___joystick_event.html#aca8acd11e7aeec63836360024c124f6c", null ],
    [ "linkToVICIIRegisters", "class_c64_1_1_v_i_c_i_i___joystick_event.html#a24f52e6d35becb462463c9ef9032ea84", null ],
    [ "processEvent", "class_c64_1_1_v_i_c_i_i___joystick_event.html#a12e7216a8de180d5f69f5ca7a515ef56", null ]
];