var dir_d44c64559bbebec7f509842c48db8b23 =
[
    [ "ASSEMBLER", "dir_6b118c8c45dba0ac59f9d793c3bb1d4c.html", "dir_6b118c8c45dba0ac59f9d793c3bb1d4c" ],
    [ "C64", "dir_235a3302aac12b217b6390653588fb9a.html", "dir_235a3302aac12b217b6390653588fb9a" ],
    [ "COMMS", "dir_49209918626551d42fff88a62600df35.html", "dir_49209918626551d42fff88a62600df35" ],
    [ "CONSOLE", "dir_b3ddaa0f2bc7f363b68290a837a43fc6.html", "dir_b3ddaa0f2bc7f363b68290a837a43fc6" ],
    [ "CORE", "dir_4581fb84a8bf7da1ab9e0691301abbd4.html", "dir_4581fb84a8bf7da1ab9e0691301abbd4" ],
    [ "CORE - copia", "dir_2350f94159f2ee09db8ba1d01c6243cb.html", "dir_2350f94159f2ee09db8ba1d01c6243cb" ],
    [ "EMULATORS", "dir_6f37776d1d4fcb060f1baab2ae3e785d.html", "dir_6f37776d1d4fcb060f1baab2ae3e785d" ],
    [ "F6500", "dir_28d72999384fc705503bdcd5dd25a428.html", "dir_28d72999384fc705503bdcd5dd25a428" ],
    [ "doxy.hpp", "doxy_8hpp.html", null ]
];