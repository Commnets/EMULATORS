var class_m_c_h_emul_1_1_phisical_storage =
[
    [ "Type", "class_m_c_h_emul_1_1_phisical_storage.html#af465c5cb3419553700d9c2afd5c77aae", [
      [ "_ROM", "class_m_c_h_emul_1_1_phisical_storage.html#af465c5cb3419553700d9c2afd5c77aaeac31ea1a52ec4200b85d92919d2cf30f0", null ],
      [ "_RAM", "class_m_c_h_emul_1_1_phisical_storage.html#af465c5cb3419553700d9c2afd5c77aaea91c66a4044c50802f76fd9070c09ba2a", null ]
    ] ],
    [ "PhisicalStorage", "class_m_c_h_emul_1_1_phisical_storage.html#a1b0231346673399336cfa04137c7f997", null ],
    [ "PhisicalStorage", "class_m_c_h_emul_1_1_phisical_storage.html#a093f7fdb9e580e967c5998337388a765", null ],
    [ "PhisicalStorage", "class_m_c_h_emul_1_1_phisical_storage.html#a29c8d0bc4ee60b8866d38c6fe1db2189", null ],
    [ "bytes", "class_m_c_h_emul_1_1_phisical_storage.html#a18943dc577b5276972b642bc34f5e2cf", null ],
    [ "canBeWriten", "class_m_c_h_emul_1_1_phisical_storage.html#ad1e63877a1dc737d9c16b4acbf08ef05", null ],
    [ "id", "class_m_c_h_emul_1_1_phisical_storage.html#a2a7dc24c58865800931c97870052dc99", null ],
    [ "loadInto", "class_m_c_h_emul_1_1_phisical_storage.html#a41a010342c97fc8fcf64e5bdcd9b2e5d", null ],
    [ "operator=", "class_m_c_h_emul_1_1_phisical_storage.html#a1586810552a95f3aa887918b8ed9ebef", null ],
    [ "set", "class_m_c_h_emul_1_1_phisical_storage.html#aaa2a7b109b6f079a4981af035dd7ae42", null ],
    [ "set", "class_m_c_h_emul_1_1_phisical_storage.html#a5fe8aaaced4e084c132f795186bb2609", null ],
    [ "set", "class_m_c_h_emul_1_1_phisical_storage.html#a9c5129fd3b20511defe52306de1cc615", null ],
    [ "size", "class_m_c_h_emul_1_1_phisical_storage.html#a51b92b91734b332acbf21b300ad9674c", null ],
    [ "type", "class_m_c_h_emul_1_1_phisical_storage.html#a9bb6ad50f282f1d8fc84bccd66b52a80", null ],
    [ "value", "class_m_c_h_emul_1_1_phisical_storage.html#afe23422b938098f54ea9740748789c9c", null ],
    [ "values", "class_m_c_h_emul_1_1_phisical_storage.html#a5180c00677242ea924fc42d66a3f529f", null ],
    [ "_data", "class_m_c_h_emul_1_1_phisical_storage.html#a4692f5e088fdb60d57fa7f0e67860d90", null ],
    [ "_id", "class_m_c_h_emul_1_1_phisical_storage.html#a6435e9de3929cd359a08788e60d5db49", null ],
    [ "_type", "class_m_c_h_emul_1_1_phisical_storage.html#a3c51810d05703a9fd7d61245832ad25c", null ],
    [ "PhisicalStorageSubset", "class_m_c_h_emul_1_1_phisical_storage.html#a155c16fe578cc3e3e4e0bf9119daae7d", null ]
];