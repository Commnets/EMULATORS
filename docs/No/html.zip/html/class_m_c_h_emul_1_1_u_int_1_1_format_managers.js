var class_m_c_h_emul_1_1_u_int_1_1_format_managers =
[
    [ "FormatManagers", "class_m_c_h_emul_1_1_u_int_1_1_format_managers.html#aa0429aa1461f681d77b0f80de6b3419f", null ],
    [ "~FormatManagers", "class_m_c_h_emul_1_1_u_int_1_1_format_managers.html#a08519df6870f1da2137d644d4d03bd7d", null ],
    [ "_formatManagers", "class_m_c_h_emul_1_1_u_int_1_1_format_managers.html#ac1dea24b9c6de970a794934e3baad555", null ]
];