var class_f_z80_1_1_r_e_s___index =
[
    [ "RES_Index", "class_f_z80_1_1_r_e_s___index.html#adec2029fa6c49e8d70b9472c901c8cef", null ],
    [ "shapeCodeWithData", "class_f_z80_1_1_r_e_s___index.html#a2517dcd49ff202cacaecafafd71f911f", null ]
];