var class_c64_1_1_c_i_a_timer =
[
    [ "CountMode", "class_c64_1_1_c_i_a_timer.html#a6f665aec08358dc74c84cb7dafb076e4", [
      [ "_PROCESSORCYCLES", "class_c64_1_1_c_i_a_timer.html#a6f665aec08358dc74c84cb7dafb076e4afb5b97f8b31c26551cc6a36bdedbb1dd", null ],
      [ "_SIGNALSONCNTLINE", "class_c64_1_1_c_i_a_timer.html#a6f665aec08358dc74c84cb7dafb076e4aae287d92dd946db027611fa852fc3103", null ],
      [ "_TIMERCOUNTSDOWNTO0", "class_c64_1_1_c_i_a_timer.html#a6f665aec08358dc74c84cb7dafb076e4a4ee36b63525a68a79096f0bdf9cf2674", null ],
      [ "_0ONCNTPULSES", "class_c64_1_1_c_i_a_timer.html#a6f665aec08358dc74c84cb7dafb076e4a8f80b369f6af0b5ed016de58320b8bd3", null ]
    ] ],
    [ "RunMode", "class_c64_1_1_c_i_a_timer.html#afab97c6af22e390e5a652fad62557b0c", [
      [ "_RESTART", "class_c64_1_1_c_i_a_timer.html#afab97c6af22e390e5a652fad62557b0ca212d6f209128ea3212aa5280d7336f3f", null ],
      [ "_ONETIME", "class_c64_1_1_c_i_a_timer.html#afab97c6af22e390e5a652fad62557b0ca50e937b52dd165cae1edd7b9acd5d353", null ]
    ] ],
    [ "CIATimer", "class_c64_1_1_c_i_a_timer.html#a2b44b7df089f442cf0a483217343e186", null ],
    [ "countMode", "class_c64_1_1_c_i_a_timer.html#ad7ccf3276e94d6b30d5cb5d458fb3ecb", null ],
    [ "currentValue", "class_c64_1_1_c_i_a_timer.html#a7ebc5beb6696d10fdc54e5d1638563e7", null ],
    [ "enabled", "class_c64_1_1_c_i_a_timer.html#aeba2d5956ca78c9201b1c9408da77d26", null ],
    [ "getInfoStructure", "class_c64_1_1_c_i_a_timer.html#a19428b389113fba1e2aae0fccbd75caa", null ],
    [ "id", "class_c64_1_1_c_i_a_timer.html#a7634f3fa02e9cb01f3ff372819a66071", null ],
    [ "initialize", "class_c64_1_1_c_i_a_timer.html#a71f72ec9a213921905b1f2481ec57b69", null ],
    [ "initialValue", "class_c64_1_1_c_i_a_timer.html#a2cbbf0c1c49957868ff13651561429ae", null ],
    [ "IRQEnabled", "class_c64_1_1_c_i_a_timer.html#a30127f687006f09a14638d6d048b5b43", null ],
    [ "IRQRequested", "class_c64_1_1_c_i_a_timer.html#a98e1d68848c790a2d3994c6b4b79c2b9", null ],
    [ "reaches0", "class_c64_1_1_c_i_a_timer.html#a9758b09da4ef890b5e09eb819fda6f65", null ],
    [ "reset", "class_c64_1_1_c_i_a_timer.html#a491161707e2db28fe4d05e1a0e1c243e", null ],
    [ "runMode", "class_c64_1_1_c_i_a_timer.html#a6337ebeb8a94e521a74415b9795779c9", null ],
    [ "setCountMode", "class_c64_1_1_c_i_a_timer.html#a008e0fbf1dbe4b781c5e8ef1dfc0a504", null ],
    [ "setEnabled", "class_c64_1_1_c_i_a_timer.html#a0df40ccfcb8d6351330b06bfe78a6d61", null ],
    [ "setInitialValue", "class_c64_1_1_c_i_a_timer.html#a4d1a86a8b522991c8692ea575b8fced9", null ],
    [ "setIRQEnabled", "class_c64_1_1_c_i_a_timer.html#a7628e163154ffde4c6ff7382d45fc1ae", null ],
    [ "setRunMode", "class_c64_1_1_c_i_a_timer.html#a0adb0c9ea96fda60ab3e422e9417050c", null ],
    [ "simulate", "class_c64_1_1_c_i_a_timer.html#a3f6cb464f6c3d1f9c88d70153c6d1f94", null ]
];