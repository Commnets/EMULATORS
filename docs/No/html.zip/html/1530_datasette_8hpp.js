var 1530_datasette_8hpp =
[
    [ "COMMODORE::Datasette1530", "class_c_o_m_m_o_d_o_r_e_1_1_datasette1530.html", "class_c_o_m_m_o_d_o_r_e_1_1_datasette1530" ],
    [ "COMMODORE::Datasette1530P", "class_c_o_m_m_o_d_o_r_e_1_1_datasette1530_p.html", "class_c_o_m_m_o_d_o_r_e_1_1_datasette1530_p" ]
];