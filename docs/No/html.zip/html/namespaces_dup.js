var namespaces_dup =
[
    [ "C64", "namespace_c64.html", "namespace_c64" ],
    [ "Console", "namespace_console.html", "namespace_console" ],
    [ "Emuls", "namespace_emuls.html", "namespace_emuls" ],
    [ "F6500", "namespace_f6500.html", "namespace_f6500" ],
    [ "MCHEmul", "namespace_m_c_h_emul.html", "namespace_m_c_h_emul" ]
];