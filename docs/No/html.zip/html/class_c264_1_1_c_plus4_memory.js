var class_c264_1_1_c_plus4_memory =
[
    [ "CPlus4Memory", "class_c264_1_1_c_plus4_memory.html#a6a11e089cf234b88e6d8690eb95a09e3", null ],
    [ "setConfiguration", "class_c264_1_1_c_plus4_memory.html#abcea5f95737b1d27f95512541c3c95db", null ]
];