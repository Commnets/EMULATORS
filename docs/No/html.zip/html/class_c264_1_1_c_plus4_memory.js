var class_c264_1_1_c_plus4_memory =
[
    [ "CPlus4Memory", "class_c264_1_1_c_plus4_memory.html#aac578624520ce9102b7f446567ea81df", null ],
    [ "setConfiguration", "class_c264_1_1_c_plus4_memory.html#a29fe5c364ff26119ec3b1fd48fdb846a", null ]
];