var class_c_o_m_m_o_d_o_r_e_1_1_datasette_i_o_port =
[
    [ "DatasetteIOPort", "class_c_o_m_m_o_d_o_r_e_1_1_datasette_i_o_port.html#af19630c5ddbb97fdf98ec006f44be10c", null ],
    [ "connectPeripheral", "class_c_o_m_m_o_d_o_r_e_1_1_datasette_i_o_port.html#a55d52a46663396589fd7ddda5018d66f", null ],
    [ "pinD4", "class_c_o_m_m_o_d_o_r_e_1_1_datasette_i_o_port.html#a3651d9e6925030b520f99568636215c0", null ],
    [ "pinE5", "class_c_o_m_m_o_d_o_r_e_1_1_datasette_i_o_port.html#a0d4eb611179eee53441985ba372983fc", null ],
    [ "pintF6", "class_c_o_m_m_o_d_o_r_e_1_1_datasette_i_o_port.html#ab9f2c60588e2858e0462a36b04750e8c", null ]
];