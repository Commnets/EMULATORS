var class_c64_1_1_manage_paddles_command =
[
    [ "ManagePaddlesCommand", "class_c64_1_1_manage_paddles_command.html#a8c00e98563b77baee59ecdb875b9ffcb", null ],
    [ "canBeExecuted", "class_c64_1_1_manage_paddles_command.html#a030783aa862fa77717061add74d61e44", null ]
];