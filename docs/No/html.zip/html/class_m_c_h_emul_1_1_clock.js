var class_m_c_h_emul_1_1_clock =
[
    [ "Clock", "class_m_c_h_emul_1_1_clock.html#ae91852000d086b8c3e1f91a0abae24ad", null ],
    [ "Clock", "class_m_c_h_emul_1_1_clock.html#ace8b270fdf2d6cc3c042e946f3adee47", null ],
    [ "countCycles", "class_m_c_h_emul_1_1_clock.html#a1b8c3002eb6be2494a7245124f98aebc", null ],
    [ "cyclesPerSecond", "class_m_c_h_emul_1_1_clock.html#af6b907be46a94d746884c88efab21347", null ],
    [ "realCyclesPerSecond", "class_m_c_h_emul_1_1_clock.html#af14ae459040d4d64974f2dd4b2f5144c", null ],
    [ "start", "class_m_c_h_emul_1_1_clock.html#a6f1d2b7b33f948920e541d0bf7110de9", null ]
];