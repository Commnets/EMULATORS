var class_m_c_h_emul_1_1_clock =
[
    [ "Clock", "class_m_c_h_emul_1_1_clock.html#ae91852000d086b8c3e1f91a0abae24ad", null ],
    [ "Clock", "class_m_c_h_emul_1_1_clock.html#ad01cf933f65bfc8642b0439686162d74", null ],
    [ "countCycles", "class_m_c_h_emul_1_1_clock.html#a1b8c3002eb6be2494a7245124f98aebc", null ],
    [ "cyclesPerSecond", "class_m_c_h_emul_1_1_clock.html#af6b907be46a94d746884c88efab21347", null ],
    [ "factor", "class_m_c_h_emul_1_1_clock.html#a0d0312d97efc53a730a2356d3e7d93e2", null ],
    [ "realCyclesPerSecond", "class_m_c_h_emul_1_1_clock.html#af14ae459040d4d64974f2dd4b2f5144c", null ],
    [ "setFactor", "class_m_c_h_emul_1_1_clock.html#a1438534c4ee696b515c297f8c303d734", null ],
    [ "start", "class_m_c_h_emul_1_1_clock.html#a6f1d2b7b33f948920e541d0bf7110de9", null ],
    [ "tooQuick", "class_m_c_h_emul_1_1_clock.html#ab5a5f59dd2d3a3e5732e7b65a5ec7c9f", null ]
];