var class_m_c_h_emul_1_1_chip_registers =
[
    [ "ChipRegisters", "class_m_c_h_emul_1_1_chip_registers.html#ace702bcf92ab1f186884444ad64bc99c", null ],
    [ "getInfoStructure", "class_m_c_h_emul_1_1_chip_registers.html#aa6ea87290bfb40508351272040635125", null ],
    [ "numberRegisters", "class_m_c_h_emul_1_1_chip_registers.html#ae6b1c16bf507eb33ea1daef88b64b5c3", null ],
    [ "peekValue", "class_m_c_h_emul_1_1_chip_registers.html#a34d1c978053c2122c799764198802686", null ],
    [ "valueRegisters", "class_m_c_h_emul_1_1_chip_registers.html#afa3498895818bd577c7a75f70a52b376", null ]
];