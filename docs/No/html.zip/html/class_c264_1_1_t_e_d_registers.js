var class_c264_1_1_t_e_d_registers =
[
    [ "TEDRegisters", "class_c264_1_1_t_e_d_registers.html#ad0af56d836ed8b9c74ed779e54aba7ce", null ],
    [ "hiromSelected", "class_c264_1_1_t_e_d_registers.html#a50ba0ec1ccef00e66bd7a96e64808db9", null ],
    [ "initialize", "class_c264_1_1_t_e_d_registers.html#a1caf5b2e28342b541adb618da6ba4581", null ],
    [ "numberRegisters", "class_c264_1_1_t_e_d_registers.html#a4c2f86bdd9d0ad00e0cb62d2b003bfe1", null ],
    [ "peekROMAccessChanged", "class_c264_1_1_t_e_d_registers.html#a94cf14a4cb64a40d605dd37494e3d779", null ],
    [ "romAccessChanged", "class_c264_1_1_t_e_d_registers.html#ac446012d564498689c773bb7c7d803f4", null ],
    [ "setJoystickPins", "class_c264_1_1_t_e_d_registers.html#ae0b96d2bbbfce13b22bbcd1e8661e0d1", null ]
];