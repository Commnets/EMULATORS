var class_m_c_h_emul_1_1_chips_list_command =
[
    [ "ChipsListCommand", "class_m_c_h_emul_1_1_chips_list_command.html#a62fa936e87444ab38528f1575c657b83", null ],
    [ "canBeExecuted", "class_m_c_h_emul_1_1_chips_list_command.html#aed96bfec53b7a9def83f13203359cbdb", null ]
];