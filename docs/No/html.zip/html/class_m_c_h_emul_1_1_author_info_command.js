var class_m_c_h_emul_1_1_author_info_command =
[
    [ "AuthorInfoCommand", "class_m_c_h_emul_1_1_author_info_command.html#a50484259c5e3c9b19e617d41564f0d7e", null ],
    [ "canBeExecuted", "class_m_c_h_emul_1_1_author_info_command.html#ae03e949fe0f17208ae0e81d686b03367", null ]
];