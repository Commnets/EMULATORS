var class_c_o_m_m_o_d_o_r_e_1_1_serial_i_o_port =
[
    [ "SerialIOPort", "class_c_o_m_m_o_d_o_r_e_1_1_serial_i_o_port.html#a56333d28c2a49a5a31400af282ebd202", null ],
    [ "connectPeripheral", "class_c_o_m_m_o_d_o_r_e_1_1_serial_i_o_port.html#a653ec885f20fed5af4bf6d567a73c825", null ]
];