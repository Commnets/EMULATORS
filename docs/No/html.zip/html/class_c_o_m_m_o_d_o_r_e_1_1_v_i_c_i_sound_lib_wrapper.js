var class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_lib_wrapper =
[
    [ "VICISoundLibWrapper", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_lib_wrapper.html#a8c67328d0d205c16900823c73028a3c9", null ],
    [ "getData", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_lib_wrapper.html#a99c1c23258ba7566301901bb34575e6f", null ],
    [ "getVoiceInfoStructure", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_lib_wrapper.html#a4e0460aadaa96f19f2b56bb8f540b59d", null ],
    [ "peekValue", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_lib_wrapper.html#afdc2f9eddaffa23e23d324afe82135da", null ],
    [ "readValue", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_lib_wrapper.html#ac782fd97bfd26d326e0dfe7f6009abd2", null ],
    [ "setValue", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_lib_wrapper.html#ac99b8b0e010e02f53f18c716ee3ed5c0", null ],
    [ "_lastValueRead", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_lib_wrapper.html#ae3ae6927a560c96eb2209e76f2658c4b", null ]
];