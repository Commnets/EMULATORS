var class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_lib_wrapper =
[
    [ "VICISoundLibWrapper", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_lib_wrapper.html#aae7325498883b02daadb3c7d0fc730cf", null ],
    [ "getInfoStructure", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_lib_wrapper.html#ae832ad13f86bc6f2fe23c9811d0a3916", null ],
    [ "getVoiceInfoStructure", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_lib_wrapper.html#a7165eac9c25dab2c41a4e6f26f9dc5ab", null ],
    [ "peekValue", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_lib_wrapper.html#afdc2f9eddaffa23e23d324afe82135da", null ],
    [ "readValue", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_lib_wrapper.html#a79ebc88222e30fca7868d9bad75fd659", null ],
    [ "setValue", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_lib_wrapper.html#ad092aa879ab9ad13ab1bccb57a4ae3d2", null ],
    [ "_lastValueRead", "class_c_o_m_m_o_d_o_r_e_1_1_v_i_c_i_sound_lib_wrapper.html#ae3ae6927a560c96eb2209e76f2658c4b", null ]
];