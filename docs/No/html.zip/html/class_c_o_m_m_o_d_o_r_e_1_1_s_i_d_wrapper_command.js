var class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_wrapper_command =
[
    [ "SIDWrapperCommand", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_wrapper_command.html#abce26425e975554c0be9fb6e5852b849", null ],
    [ "canBeExecuted", "class_c_o_m_m_o_d_o_r_e_1_1_s_i_d_wrapper_command.html#a3ed03d9e1d9f5a7442045080b37eb348", null ]
];