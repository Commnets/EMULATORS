var class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_sound_lib_wrapper =
[
    [ "TEDSoundLibWrapper", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_sound_lib_wrapper.html#a54194ae86e9b215464094b4d719e32de", null ],
    [ "getInfoStructure", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_sound_lib_wrapper.html#afeea539c56209f0e942bed42afab8ed9", null ],
    [ "getVoiceInfoStructure", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_sound_lib_wrapper.html#a060f11ee0733c3f5c3b2bb8bf1649694", null ],
    [ "peekValue", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_sound_lib_wrapper.html#a170bbb479024a8f82c57476931e21d6f", null ],
    [ "readValue", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_sound_lib_wrapper.html#acad5d998dd3fa3ad788859db00059d8a", null ],
    [ "setValue", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_sound_lib_wrapper.html#aad42b73772918d54e167f197505b4e61", null ],
    [ "_lastValueRead", "class_c_o_m_m_o_d_o_r_e_1_1_t_e_d_sound_lib_wrapper.html#aeb18012227a2dad600f9ff65c0ee75fc", null ]
];