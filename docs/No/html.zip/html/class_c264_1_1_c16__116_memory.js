var class_c264_1_1_c16__116_memory =
[
    [ "C16_116Memory", "class_c264_1_1_c16__116_memory.html#aeccb8b116d03f5570fe0edae4163ac4f", null ],
    [ "setConfiguration", "class_c264_1_1_c16__116_memory.html#a203234259a6c930bcdc58dba262b2cbb", null ]
];