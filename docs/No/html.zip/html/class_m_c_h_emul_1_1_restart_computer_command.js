var class_m_c_h_emul_1_1_restart_computer_command =
[
    [ "RestartComputerCommand", "class_m_c_h_emul_1_1_restart_computer_command.html#ac072e389d71c52ab1b866bc74b3f4da9", null ],
    [ "canBeExecuted", "class_m_c_h_emul_1_1_restart_computer_command.html#a07ac1ca9132e21f8690c6066fa2d6cde", null ]
];