var class_m_c_h_emul_1_1_info_class =
[
    [ "InfoClass", "class_m_c_h_emul_1_1_info_class.html#a8d03dc915eeeff94961c72b9e966e79c", null ],
    [ "InfoClass", "class_m_c_h_emul_1_1_info_class.html#a34487e08fab3f779b5cc71425a6733d9", null ],
    [ "className", "class_m_c_h_emul_1_1_info_class.html#a622da62825b76fc59a210a2e5b99cd09", null ],
    [ "getInfoStructure", "class_m_c_h_emul_1_1_info_class.html#ad68f2935726df4bc510db045393d8925", null ],
    [ "setClassName", "class_m_c_h_emul_1_1_info_class.html#a8d0acf139720fbf428fadb75425b4fe8", null ],
    [ "operator<<", "class_m_c_h_emul_1_1_info_class.html#af70cde0cab55a08636995d3e5d6177e5", null ]
];