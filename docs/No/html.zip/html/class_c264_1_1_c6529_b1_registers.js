var class_c264_1_1_c6529_b1_registers =
[
    [ "C6529B1Registers", "class_c264_1_1_c6529_b1_registers.html#a4401f7220726bf862a0c3e2205fe6611", null ],
    [ "numberRegisters", "class_c264_1_1_c6529_b1_registers.html#a3fd2beceaf15447a389ba226daa52cc5", null ],
    [ "C6529B1", "class_c264_1_1_c6529_b1_registers.html#a24d601cb910048ab505bf9597eb01fb8", null ]
];