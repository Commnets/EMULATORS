var class_c264_1_1_commodore_plus4 =
[
    [ "CommodorePlus4", "class_c264_1_1_commodore_plus4.html#a7de382d939350a0ff486862f9fb1b931", null ]
];