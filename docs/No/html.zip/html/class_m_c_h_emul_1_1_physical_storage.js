var class_m_c_h_emul_1_1_physical_storage =
[
    [ "Type", "class_m_c_h_emul_1_1_physical_storage.html#a0948bfb948849ce9e430455169ece5e5", [
      [ "_ROM", "class_m_c_h_emul_1_1_physical_storage.html#a0948bfb948849ce9e430455169ece5e5ac31ea1a52ec4200b85d92919d2cf30f0", null ],
      [ "_RAM", "class_m_c_h_emul_1_1_physical_storage.html#a0948bfb948849ce9e430455169ece5e5a91c66a4044c50802f76fd9070c09ba2a", null ]
    ] ],
    [ "PhysicalStorage", "class_m_c_h_emul_1_1_physical_storage.html#a452edc1517d5c6ef5e81d88fe1aa9315", null ],
    [ "PhysicalStorage", "class_m_c_h_emul_1_1_physical_storage.html#aa065f4c424a93a3202689259cb556724", null ],
    [ "PhysicalStorage", "class_m_c_h_emul_1_1_physical_storage.html#ab083f7bb0d196c3512930a7ff1b8cb0c", null ],
    [ "bytes", "class_m_c_h_emul_1_1_physical_storage.html#a1b2fe068819dead71ca98c504b1827a2", null ],
    [ "canBeWriten", "class_m_c_h_emul_1_1_physical_storage.html#a70363873119e9d7f50fe1d7c3e7215e4", null ],
    [ "id", "class_m_c_h_emul_1_1_physical_storage.html#ad36d73ba9419500e5eadd5bbe323687d", null ],
    [ "loadInto", "class_m_c_h_emul_1_1_physical_storage.html#a81cfc7d6db27234822af3bb0079a1630", null ],
    [ "operator=", "class_m_c_h_emul_1_1_physical_storage.html#a24d0d419dae7f24a719b3ba7b80107ae", null ],
    [ "set", "class_m_c_h_emul_1_1_physical_storage.html#ac9c338cb55cd8cb82b51a4cb4cfd2a8b", null ],
    [ "set", "class_m_c_h_emul_1_1_physical_storage.html#af5b1a814fea1c775eb61695612b05a3e", null ],
    [ "set", "class_m_c_h_emul_1_1_physical_storage.html#a40960dbe410c7b709264171a1afbe00a", null ],
    [ "size", "class_m_c_h_emul_1_1_physical_storage.html#afe03ec4d82300cc5c9c48364ce019abd", null ],
    [ "type", "class_m_c_h_emul_1_1_physical_storage.html#a9ad1d55c2f41dd01cd0f47c6a043c444", null ],
    [ "value", "class_m_c_h_emul_1_1_physical_storage.html#aff967c39de399a7b1b96de9f2d546251", null ],
    [ "values", "class_m_c_h_emul_1_1_physical_storage.html#a3e8534522331a48aa5d15b90696743a6", null ],
    [ "_data", "class_m_c_h_emul_1_1_physical_storage.html#a45f9fc6acdde076cb98b7339a3a0fb86", null ],
    [ "_id", "class_m_c_h_emul_1_1_physical_storage.html#a974bfae37438acedf19c6fc025e42329", null ],
    [ "_type", "class_m_c_h_emul_1_1_physical_storage.html#a9ebe6b12a935f3249d861e8b1feefcee", null ],
    [ "PhysicalStorageSubset", "class_m_c_h_emul_1_1_physical_storage.html#ac3df13a565f4da3372f39d194695668d", null ]
];