var dir_4696acade077342aea720a65ae3e09a5 =
[
    [ "Channel.hpp", "_c_o_m_m_s_01-_01copia_2_channel_8hpp.html", [
      [ "MCHEmul::PeerCommunicationChannel", "class_m_c_h_emul_1_1_peer_communication_channel.html", "class_m_c_h_emul_1_1_peer_communication_channel" ],
      [ "MCHEmul::PeerCommunicationChannel::MsgToSend", "struct_m_c_h_emul_1_1_peer_communication_channel_1_1_msg_to_send.html", "struct_m_c_h_emul_1_1_peer_communication_channel_1_1_msg_to_send" ]
    ] ],
    [ "incs.hpp", "_c_o_m_m_s_01-_01copia_2incs_8hpp.html", null ],
    [ "IPAddress.hpp", "_c_o_m_m_s_01-_01copia_2_i_p_address_8hpp.html", [
      [ "MCHEmul::IPAddress", "class_m_c_h_emul_1_1_i_p_address.html", "class_m_c_h_emul_1_1_i_p_address" ]
    ] ],
    [ "System.hpp", "_c_o_m_m_s_01-_01copia_2_system_8hpp.html", [
      [ "MCHEmul::CommunicationSystem", "class_m_c_h_emul_1_1_communication_system.html", "class_m_c_h_emul_1_1_communication_system" ]
    ] ]
];