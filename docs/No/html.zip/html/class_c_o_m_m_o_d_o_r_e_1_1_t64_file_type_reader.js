var class_c_o_m_m_o_d_o_r_e_1_1_t64_file_type_reader =
[
    [ "T64FileTypeReader", "class_c_o_m_m_o_d_o_r_e_1_1_t64_file_type_reader.html#afb802b4545fa6f60fef61e37cd2e8ddc", null ],
    [ "canRead", "class_c_o_m_m_o_d_o_r_e_1_1_t64_file_type_reader.html#a86126f5037e427bb9b8a7a634e08094d", null ],
    [ "readFile", "class_c_o_m_m_o_d_o_r_e_1_1_t64_file_type_reader.html#a37f829bb93ca2dfa3c36277a009d2e5e", null ]
];