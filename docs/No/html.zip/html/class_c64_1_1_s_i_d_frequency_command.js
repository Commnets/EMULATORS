var class_c64_1_1_s_i_d_frequency_command =
[
    [ "SIDFrequencyCommand", "class_c64_1_1_s_i_d_frequency_command.html#a9f92c21b75cb7f7c8611782da78c8aa4", null ],
    [ "canBeExecuted", "class_c64_1_1_s_i_d_frequency_command.html#a6269b0139e1c8d02a6d75c4120933d27", null ]
];