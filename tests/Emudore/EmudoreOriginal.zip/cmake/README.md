These have been downloaded from:

https://github.com/tcbrindle/sdl2-cmake-scripts
