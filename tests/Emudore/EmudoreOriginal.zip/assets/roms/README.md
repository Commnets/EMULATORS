The following files have been downloaded from: 

ftp://www.zimmers.net/pub/cbm/firmware/computers/c64/

Please, bear in mind that these files might be subject to other licenses
than emudore's

# kernal.901227-03.bin

  This 8-kilobyte 2364 ROM is the third and essentially last revision of 
  the Commodore 64 KERNAL. It is the most widely spread version.

# basic.901226-01.bin

  Commodore 64 BASIC V2. The first and essentially only revision, located at 
  $A000-$BFFF. In the 64GS system firmware, the 30 unused bytes at $BF53-$BF70 
  are filled with $00 instead of $AA. In the Commodore 65 firmware, these bytes 
  are filled with $FF.

# characters.901225-01.bin

  The character generator ROM.
