These are Klaus Dormann 6502 functional tests, also available at:

https://github.com/Klaus2m5/6502_65C02_functional_tests

# 6502_functional_test.a65

  Source code

# 6502_functional_test.bin

  Assembled binary to be loaded at 0x400

# 6502_functional_test.lst

  Listing file, comes in useful to identify bugs, since these tests have no 
  actual output.
