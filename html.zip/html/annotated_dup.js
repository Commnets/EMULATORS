var annotated_dup =
[
    [ "C64", "namespace_c64.html", [
      [ "Commodore64", "class_c64_1_1_commodore64.html", "class_c64_1_1_commodore64" ]
    ] ],
    [ "F6500", "namespace_f6500.html", [
      [ "ADC_General", "class_f6500_1_1_a_d_c___general.html", "class_f6500_1_1_a_d_c___general" ],
      [ "AND_General", "class_f6500_1_1_a_n_d___general.html", "class_f6500_1_1_a_n_d___general" ],
      [ "ASL_General", "class_f6500_1_1_a_s_l___general.html", "class_f6500_1_1_a_s_l___general" ],
      [ "BXX_General", "class_f6500_1_1_b_x_x___general.html", "class_f6500_1_1_b_x_x___general" ],
      [ "C6510", "class_f6500_1_1_c6510.html", "class_f6500_1_1_c6510" ],
      [ "CMP_General", "class_f6500_1_1_c_m_p___general.html", "class_f6500_1_1_c_m_p___general" ],
      [ "CPX_General", "class_f6500_1_1_c_p_x___general.html", "class_f6500_1_1_c_p_x___general" ],
      [ "CPY_General", "class_f6500_1_1_c_p_y___general.html", "class_f6500_1_1_c_p_y___general" ],
      [ "DEC_General", "class_f6500_1_1_d_e_c___general.html", "class_f6500_1_1_d_e_c___general" ],
      [ "EOR_General", "class_f6500_1_1_e_o_r___general.html", "class_f6500_1_1_e_o_r___general" ],
      [ "INC_General", "class_f6500_1_1_i_n_c___general.html", "class_f6500_1_1_i_n_c___general" ],
      [ "Instruction", "class_f6500_1_1_instruction.html", "class_f6500_1_1_instruction" ],
      [ "LDA_General", "class_f6500_1_1_l_d_a___general.html", "class_f6500_1_1_l_d_a___general" ],
      [ "LDX_General", "class_f6500_1_1_l_d_x___general.html", "class_f6500_1_1_l_d_x___general" ],
      [ "LDY_General", "class_f6500_1_1_l_d_y___general.html", "class_f6500_1_1_l_d_y___general" ],
      [ "LSR_General", "class_f6500_1_1_l_s_r___general.html", "class_f6500_1_1_l_s_r___general" ],
      [ "ORA_General", "class_f6500_1_1_o_r_a___general.html", "class_f6500_1_1_o_r_a___general" ],
      [ "ROL_General", "class_f6500_1_1_r_o_l___general.html", "class_f6500_1_1_r_o_l___general" ],
      [ "ROR_General", "class_f6500_1_1_r_o_r___general.html", "class_f6500_1_1_r_o_r___general" ],
      [ "SBC_General", "class_f6500_1_1_s_b_c___general.html", "class_f6500_1_1_s_b_c___general" ],
      [ "STA_General", "class_f6500_1_1_s_t_a___general.html", "class_f6500_1_1_s_t_a___general" ],
      [ "STX_General", "class_f6500_1_1_s_t_x___general.html", "class_f6500_1_1_s_t_x___general" ],
      [ "STY_General", "class_f6500_1_1_s_t_y___general.html", "class_f6500_1_1_s_t_y___general" ]
    ] ],
    [ "MCHEmul", "namespace_m_c_h_emul.html", [
      [ "Address", "class_m_c_h_emul_1_1_address.html", "class_m_c_h_emul_1_1_address" ],
      [ "Chip", "class_m_c_h_emul_1_1_chip.html", "class_m_c_h_emul_1_1_chip" ],
      [ "Computer", "class_m_c_h_emul_1_1_computer.html", "class_m_c_h_emul_1_1_computer" ],
      [ "CPU", "class_m_c_h_emul_1_1_c_p_u.html", "class_m_c_h_emul_1_1_c_p_u" ],
      [ "CPUArchitecture", "class_m_c_h_emul_1_1_c_p_u_architecture.html", "class_m_c_h_emul_1_1_c_p_u_architecture" ],
      [ "CPUInterrupt", "class_m_c_h_emul_1_1_c_p_u_interrupt.html", "class_m_c_h_emul_1_1_c_p_u_interrupt" ],
      [ "Instruction", "class_m_c_h_emul_1_1_instruction.html", "class_m_c_h_emul_1_1_instruction" ],
      [ "Memory", "class_m_c_h_emul_1_1_memory.html", "class_m_c_h_emul_1_1_memory" ],
      [ "NoChip", "class_m_c_h_emul_1_1_no_chip.html", "class_m_c_h_emul_1_1_no_chip" ],
      [ "ProgramCounter", "class_m_c_h_emul_1_1_program_counter.html", "class_m_c_h_emul_1_1_program_counter" ],
      [ "Register", "class_m_c_h_emul_1_1_register.html", "class_m_c_h_emul_1_1_register" ],
      [ "Stack", "class_m_c_h_emul_1_1_stack.html", "class_m_c_h_emul_1_1_stack" ],
      [ "StatusRegister", "class_m_c_h_emul_1_1_status_register.html", "class_m_c_h_emul_1_1_status_register" ],
      [ "UByte", "class_m_c_h_emul_1_1_u_byte.html", "class_m_c_h_emul_1_1_u_byte" ],
      [ "UBytes", "class_m_c_h_emul_1_1_u_bytes.html", "class_m_c_h_emul_1_1_u_bytes" ],
      [ "UInt", "class_m_c_h_emul_1_1_u_int.html", "class_m_c_h_emul_1_1_u_int" ]
    ] ]
];