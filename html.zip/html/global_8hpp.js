var global_8hpp =
[
    [ "Attributes", "global_8hpp.html#af95db4f8a743a6bcbdde7fc33f1424f8", null ],
    [ "operator<<", "global_8hpp.html#a34b1f7efed00d57ddde9662468565813", null ],
    [ "_CHIP_ERROR", "global_8hpp.html#a75aa94e0068f8adde67a7593929af617", null ],
    [ "_CPU_ERROR", "global_8hpp.html#a16366daea14b37a5e32db63b5ffdfa7b", null ],
    [ "_INIT_ERROR", "global_8hpp.html#a3111d4f11af30abecc3e75758edf5622", null ],
    [ "_MAXBYTESMANAGED", "global_8hpp.html#a2959abce9ac82a9c41a516831209345c", null ],
    [ "_NOERROR", "global_8hpp.html#a2fb73d7cba566aa711762f8ff7d9197d", null ],
    [ "AttributedNotDefined", "global_8hpp.html#a82e559f09bf8dfe2637b121167918694", null ]
];