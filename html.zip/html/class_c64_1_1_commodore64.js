var class_c64_1_1_commodore64 =
[
    [ "VisualSystem", "class_c64_1_1_commodore64.html#a1e15f030c14e0ada1684d25f518806d1", [
      [ "_NTSC", "class_c64_1_1_commodore64.html#a1e15f030c14e0ada1684d25f518806d1adeec6f82de7a84a41d870c1337eaa54f", null ],
      [ "_PAL", "class_c64_1_1_commodore64.html#a1e15f030c14e0ada1684d25f518806d1a583a9380fed8c3f36501194a00fa90f5", null ]
    ] ],
    [ "Commodore64", "class_c64_1_1_commodore64.html#a87fbe14975e8c73bd5b5cd57c4ca7c0b", null ],
    [ "initialize", "class_c64_1_1_commodore64.html#ad1bd4391385c94382c412e8a6a33fdb2", null ]
];