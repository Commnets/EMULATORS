var struct_m_c_h_emul_1_1_communication_channel_1_1_server_data =
[
    [ "ServerData", "struct_m_c_h_emul_1_1_communication_channel_1_1_server_data.html#ad0beefb7de6d8a2333ba2354f7561a17", null ],
    [ "ServerData", "struct_m_c_h_emul_1_1_communication_channel_1_1_server_data.html#ad59180e8b0f5af69d1a8280e7a620b10", null ],
    [ "ServerData", "struct_m_c_h_emul_1_1_communication_channel_1_1_server_data.html#a3deb5893557a5667969ed85811a54f72", null ],
    [ "operator=", "struct_m_c_h_emul_1_1_communication_channel_1_1_server_data.html#acee5d53998fe3b3c5345f95089b4d7ce", null ],
    [ "_listenAtPort", "struct_m_c_h_emul_1_1_communication_channel_1_1_server_data.html#a08ef255e425b7010ebd916bec9f62b09", null ],
    [ "_simultaneousConnections", "struct_m_c_h_emul_1_1_communication_channel_1_1_server_data.html#a743c657e2ba7bca11b40f92c71deac30", null ]
];