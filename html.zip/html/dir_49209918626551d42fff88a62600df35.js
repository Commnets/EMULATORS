var dir_49209918626551d42fff88a62600df35 =
[
    [ "Channel.hpp", "_channel_8hpp.html", [
      [ "MCHEmul::CommunicationChannel", "class_m_c_h_emul_1_1_communication_channel.html", "class_m_c_h_emul_1_1_communication_channel" ],
      [ "MCHEmul::CommunicationChannel::ServerData", "struct_m_c_h_emul_1_1_communication_channel_1_1_server_data.html", "struct_m_c_h_emul_1_1_communication_channel_1_1_server_data" ],
      [ "MCHEmul::CommunicationChannel::Data", "union_m_c_h_emul_1_1_communication_channel_1_1_data.html", "union_m_c_h_emul_1_1_communication_channel_1_1_data" ]
    ] ],
    [ "IPAddress.hpp", "_i_p_address_8hpp.html", [
      [ "MCHEmul::IPAddress", "class_m_c_h_emul_1_1_i_p_address.html", "class_m_c_h_emul_1_1_i_p_address" ]
    ] ],
    [ "Message.hpp", "_message_8hpp.html", [
      [ "MCHEmul::CommunicationMessage", "class_m_c_h_emul_1_1_communication_message.html", "class_m_c_h_emul_1_1_communication_message" ],
      [ "MCHEmul::MessageBuilder", "class_m_c_h_emul_1_1_message_builder.html", "class_m_c_h_emul_1_1_message_builder" ]
    ] ],
    [ "StdMessages.hpp", "_std_messages_8hpp.html", [
      [ "MCHEmul::StandardMessageBuilder", "class_m_c_h_emul_1_1_standard_message_builder.html", "class_m_c_h_emul_1_1_standard_message_builder" ],
      [ "MCHEmul::GetRegisterStatusMessage", "class_m_c_h_emul_1_1_get_register_status_message.html", "class_m_c_h_emul_1_1_get_register_status_message" ],
      [ "MCHEmul::GetMemoryDataMessage", "class_m_c_h_emul_1_1_get_memory_data_message.html", "class_m_c_h_emul_1_1_get_memory_data_message" ]
    ] ],
    [ "System.hpp", "_system_8hpp.html", [
      [ "MCHEmul::CommunicationSystem", "class_m_c_h_emul_1_1_communication_system.html", "class_m_c_h_emul_1_1_communication_system" ]
    ] ]
];