var namespace_c64 =
[
    [ "CIA1", "class_c64_1_1_c_i_a1.html", "class_c64_1_1_c_i_a1" ],
    [ "CIA1Memory", "class_c64_1_1_c_i_a1_memory.html", "class_c64_1_1_c_i_a1_memory" ],
    [ "CIA2", "class_c64_1_1_c_i_a2.html", "class_c64_1_1_c_i_a2" ],
    [ "CIA2Memory", "class_c64_1_1_c_i_a2_memory.html", "class_c64_1_1_c_i_a2_memory" ],
    [ "ColorRAMMemory", "class_c64_1_1_color_r_a_m_memory.html", "class_c64_1_1_color_r_a_m_memory" ],
    [ "Commodore64", "class_c64_1_1_commodore64.html", "class_c64_1_1_commodore64" ],
    [ "InputOSSystem", "class_c64_1_1_input_o_s_system.html", "class_c64_1_1_input_o_s_system" ],
    [ "Screen", "class_c64_1_1_screen.html", "class_c64_1_1_screen" ],
    [ "ScreenNTSC", "class_c64_1_1_screen_n_t_s_c.html", "class_c64_1_1_screen_n_t_s_c" ],
    [ "ScreenPAL", "class_c64_1_1_screen_p_a_l.html", "class_c64_1_1_screen_p_a_l" ],
    [ "VICII", "class_c64_1_1_v_i_c_i_i.html", "class_c64_1_1_v_i_c_i_i" ],
    [ "VICII_NTSC", "class_c64_1_1_v_i_c_i_i___n_t_s_c.html", "class_c64_1_1_v_i_c_i_i___n_t_s_c" ],
    [ "VICII_PAL", "class_c64_1_1_v_i_c_i_i___p_a_l.html", "class_c64_1_1_v_i_c_i_i___p_a_l" ],
    [ "VICMemory", "class_c64_1_1_v_i_c_memory.html", "class_c64_1_1_v_i_c_memory" ]
];