var class_f6500_1_1_c6510 =
[
    [ "AddressMode", "class_f6500_1_1_c6510.html#a22d9b567a90c0b02de7750a43750b5f3", [
      [ "_IMPLICIT", "class_f6500_1_1_c6510.html#a22d9b567a90c0b02de7750a43750b5f3a78a8a1eab3b9ab4d83a29ab249774dcd", null ],
      [ "_INMEDIATE", "class_f6500_1_1_c6510.html#a22d9b567a90c0b02de7750a43750b5f3ac2b1f8806727a8fe8fc9aba352ed63c5", null ],
      [ "_ABSOLUTE", "class_f6500_1_1_c6510.html#a22d9b567a90c0b02de7750a43750b5f3acab739ce16b095d16439a910ad8794a0", null ],
      [ "_ZEROPAGE", "class_f6500_1_1_c6510.html#a22d9b567a90c0b02de7750a43750b5f3adc92b8dd2d7b87711fb304ae1f9b0ade", null ],
      [ "_ABSOLUTE_X", "class_f6500_1_1_c6510.html#a22d9b567a90c0b02de7750a43750b5f3aa6e82fba9af7aa242ee8ee89a8d35d02", null ],
      [ "_ABSOLUTE_Y", "class_f6500_1_1_c6510.html#a22d9b567a90c0b02de7750a43750b5f3a9cd043ac348399b850dbb5b198441623", null ],
      [ "_RELATIVE", "class_f6500_1_1_c6510.html#a22d9b567a90c0b02de7750a43750b5f3a315d315bd4da1e10c06661d9d3d73bfd", null ],
      [ "_INDIRECT", "class_f6500_1_1_c6510.html#a22d9b567a90c0b02de7750a43750b5f3a1a41c0bc78543058851257768b2a4917", null ],
      [ "_ZEROPAGE_X", "class_f6500_1_1_c6510.html#a22d9b567a90c0b02de7750a43750b5f3a23ec6c1de841d8f5f47f209b0576d61c", null ],
      [ "_ZEROPAGE_Y", "class_f6500_1_1_c6510.html#a22d9b567a90c0b02de7750a43750b5f3afb3dc75e02a38f9213e9ee198885af33", null ],
      [ "_INDIRECT_X", "class_f6500_1_1_c6510.html#a22d9b567a90c0b02de7750a43750b5f3a614cfd7bc87a5bd4353e46e8b1cb1a20", null ],
      [ "_INDIRECT_Y", "class_f6500_1_1_c6510.html#a22d9b567a90c0b02de7750a43750b5f3a3d782573a41ee93e35275772b7426585", null ]
    ] ],
    [ "C6510", "class_f6500_1_1_c6510.html#a6bbfb444eca0bacaf6eafa93ebcf08c5", null ],
    [ "accumulator", "class_f6500_1_1_c6510.html#a6114bfd815c3cebcad5f070b60629166", null ],
    [ "xRegister", "class_f6500_1_1_c6510.html#a7c37da50fa4b4078b5b84e3e3e0e5533", null ],
    [ "yRegister", "class_f6500_1_1_c6510.html#a0c39acaa6c043e40d659e6d8690c2751", null ]
];