var class_m_c_h_emul_1_1_stack =
[
    [ "Stack", "class_m_c_h_emul_1_1_stack.html#a2f45d794f88dfdee34d1591b5b75fc02", null ],
    [ "initialize", "class_m_c_h_emul_1_1_stack.html#ad0a62159581edc8cac3dbe96ddade573", null ],
    [ "position", "class_m_c_h_emul_1_1_stack.html#ab83ad6a2e79aca0908be0785fa4ebbef", null ],
    [ "pull", "class_m_c_h_emul_1_1_stack.html#aaff33fc74ed690e2296449b3e51e4c8c", null ],
    [ "push", "class_m_c_h_emul_1_1_stack.html#a4a48072ed39c54c20093414ec53564a4", null ],
    [ "stackOverflow", "class_m_c_h_emul_1_1_stack.html#a5ceecd38265e7699004221f680258716", null ],
    [ "operator<<", "class_m_c_h_emul_1_1_stack.html#af07481bd8b6303542150ecfeb916fe50", null ]
];