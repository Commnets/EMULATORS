var searchData=
[
  ['inc_5fgeneral_0',['INC_General',['../class_f6500_1_1_i_n_c___general.html',1,'F6500']]],
  ['instruction_1',['Instruction',['../class_f6500_1_1_instruction.html',1,'F6500::Instruction'],['../class_m_c_h_emul_1_1_instruction.html',1,'MCHEmul::Instruction']]]
];
