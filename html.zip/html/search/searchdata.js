var indexSectionsWithContent =
{
  0: "_abcdefgilmnoprstuvxy~",
  1: "abcdeilmnoprsuv",
  2: "cfm",
  3: "acdgimnprsuv",
  4: "_abcdefilmnoprstuvxy~",
  5: "_a",
  6: "abcilmr",
  7: "aoptv",
  8: "_",
  9: "o",
  10: "_",
  11: "ac"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "defines",
  11: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Friends",
  10: "Macros",
  11: "Modules"
};

