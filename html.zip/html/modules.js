var modules =
[
    [ "Common classes", "group___c_p_u.html", null ],
    [ "Classes representing the a Parseer/Compiler emulator", "group___p_a_r_s_e_r.html", null ],
    [ "Classes defining the 6500 chip family", "group___f6500.html", null ],
    [ "All classes defining the C64 Computer", "group___c64.html", null ]
];