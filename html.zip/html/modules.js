var modules =
[
    [ "Common classes", "group__core.html", null ],
    [ "Classes representing the CPU language", "group__language.html", null ],
    [ "Classes defining the 6500 chip family", "group___f6500.html", null ],
    [ "All classes defining the C64 Computer", "group___c64.html", null ]
];