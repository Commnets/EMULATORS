var union_m_c_h_emul_1_1_communication_channel_1_1_data =
[
    [ "Data", "union_m_c_h_emul_1_1_communication_channel_1_1_data.html#a8ded39042ad0c5b1f1266fd4854b62d5", null ],
    [ "Data", "union_m_c_h_emul_1_1_communication_channel_1_1_data.html#ac20b0dafe82144bd7e139178b2c4c580", null ],
    [ "Data", "union_m_c_h_emul_1_1_communication_channel_1_1_data.html#a028136efeccb8a1cdc2bf55a96ca43fe", null ],
    [ "operator=", "union_m_c_h_emul_1_1_communication_channel_1_1_data.html#a7ca763d0630b6b5f861351063278af2c", null ],
    [ "_connectedTo", "union_m_c_h_emul_1_1_communication_channel_1_1_data.html#a73823849a89972666a33a2b1e4478632", null ],
    [ "_serverData", "union_m_c_h_emul_1_1_communication_channel_1_1_data.html#adf3931fc5df4801ac54f33bbed9aeda9", null ]
];