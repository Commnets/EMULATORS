var class_c64_1_1_input_o_s_system =
[
    [ "InputOSSystem", "class_c64_1_1_input_o_s_system.html#aec351c9acc49f28204c354b5df6e5100", null ],
    [ "whenKeyPressed", "class_c64_1_1_input_o_s_system.html#adcc9a5b3d917118a5cb899e9de0ef129", null ],
    [ "whenKeyReleased", "class_c64_1_1_input_o_s_system.html#a200e002b3f1c2cfb505dd6fc52ffd52e", null ]
];