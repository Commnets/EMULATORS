var dir_d44c64559bbebec7f509842c48db8b23 =
[
    [ "ASSEMBLER", "dir_6b118c8c45dba0ac59f9d793c3bb1d4c.html", "dir_6b118c8c45dba0ac59f9d793c3bb1d4c" ],
    [ "C64", "dir_235a3302aac12b217b6390653588fb9a.html", "dir_235a3302aac12b217b6390653588fb9a" ],
    [ "C64EMULATOR", "dir_c0802c5cf6c870ea4e225560378e0af8.html", "dir_c0802c5cf6c870ea4e225560378e0af8" ],
    [ "COMMS", "dir_49209918626551d42fff88a62600df35.html", "dir_49209918626551d42fff88a62600df35" ],
    [ "CORE", "dir_4581fb84a8bf7da1ab9e0691301abbd4.html", "dir_4581fb84a8bf7da1ab9e0691301abbd4" ],
    [ "F6500", "dir_28d72999384fc705503bdcd5dd25a428.html", "dir_28d72999384fc705503bdcd5dd25a428" ],
    [ "doxy.hpp", "doxy_8hpp.html", null ]
];